-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `breakpacks`
--

DROP TABLE IF EXISTS `breakpacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `breakpacks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fromCombinationId` int NOT NULL,
  `toCombinationId` int NOT NULL,
  `quantity` int NOT NULL,
  `conversionFactor` int NOT NULL,
  `createdBy` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fromCombinationId` (`fromCombinationId`),
  KEY `toCombinationId` (`toCombinationId`),
  CONSTRAINT `breakpacks_ibfk_1` FOREIGN KEY (`fromCombinationId`) REFERENCES `productcombinations` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `breakpacks_ibfk_2` FOREIGN KEY (`toCombinationId`) REFERENCES `productcombinations` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `breakpacks`
--

LOCK TABLES `breakpacks` WRITE;
/*!40000 ALTER TABLE `breakpacks` DISABLE KEYS */;
INSERT INTO `breakpacks` VALUES (1,1,5,2,12,1,'2025-08-16 00:28:01','2025-08-16 00:28:01'),(2,4,8,3,12,1,'2025-08-16 06:55:38','2025-08-16 06:55:38');
/*!40000 ALTER TABLE `breakpacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `order` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Building Materials','Foundation materials including lumber, plywood, concrete, roofing, siding, insulation, drywall, and fencing',1),(2,'Hardware','Essential small parts like fasteners (nails, screws), tools accessories, door/window/cabinet hardware, chains, and electrical boxes',2),(3,'Paint & Supplies','Interior/exterior paint, stains, spray paint, brushes, rollers, tape, wallpaper, and painting preparation materials',3),(4,'Tools','Power tools (drills, saws), hand tools (hammers, wrenches), tool storage, and outdoor power equipment (mowers, trimmers)',4),(5,'Plumbing','Water systems components including pipes, fittings, water heaters, faucets, sinks, sump pumps, and toilets',NULL),(6,'Electrical','Power and lighting systems with wiring, breakers, switches, outlets, lighting fixtures, ceiling fans, and generators',NULL),(7,'Flooring','Surface coverings like carpet, hardwood, laminate, vinyl, tile, underlayment, and area rugs',NULL),(8,'Kitchen & Bath','Renovation essentials including cabinets, countertops, sinks, faucets, vanities, bathtubs, showers, and toilets',NULL),(9,'Doors & Windows','Interior/exterior doors, various window types, and garage doors for entryways and natural light',NULL),(10,'Garden Center','Plants (trees/shrubs/flowers), soil, mulch, fertilizer, gardening tools, and pest control for landscaping',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `combinationvalues`
--

DROP TABLE IF EXISTS `combinationvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `combinationvalues` (
  `combinationId` int NOT NULL,
  `variantValueId` int NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`combinationId`,`variantValueId`),
  UNIQUE KEY `CombinationValues_variantValueId_combinationId_unique` (`combinationId`,`variantValueId`),
  KEY `variantValueId` (`variantValueId`),
  CONSTRAINT `combinationvalues_ibfk_1` FOREIGN KEY (`combinationId`) REFERENCES `productcombinations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `combinationvalues_ibfk_2` FOREIGN KEY (`variantValueId`) REFERENCES `variantvalues` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combinationvalues`
--

LOCK TABLES `combinationvalues` WRITE;
/*!40000 ALTER TABLE `combinationvalues` DISABLE KEYS */;
INSERT INTO `combinationvalues` VALUES (1,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(1,3,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(2,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(2,4,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(3,2,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(3,3,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(4,2,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(4,4,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(5,46,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(5,48,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(6,47,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(6,48,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(7,46,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(7,49,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(8,47,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(8,49,'2025-08-15 23:40:13','2025-08-15 23:40:13');
/*!40000 ALTER TABLE `combinationvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` text,
  `address` varchar(255) NOT NULL,
  `notes` text,
  `isActive` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'User',NULL,NULL,NULL,'Unknown',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventories`
--

DROP TABLE IF EXISTS `inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `combinationId` int DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `combinationId` (`combinationId`),
  CONSTRAINT `inventories_ibfk_1` FOREIGN KEY (`combinationId`) REFERENCES `productcombinations` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventories`
--

LOCK TABLES `inventories` WRITE;
/*!40000 ALTER TABLE `inventories` DISABLE KEYS */;
INSERT INTO `inventories` VALUES (1,1,8,'2025-08-15 23:35:54','2025-08-16 00:28:01'),(2,2,0,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(3,3,0,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(4,4,2,'2025-08-15 23:35:54','2025-08-16 06:55:38'),(5,5,24,'2025-08-16 00:28:01','2025-08-16 00:28:01'),(6,8,36,'2025-08-16 06:55:38','2025-08-16 06:55:38');
/*!40000 ALTER TABLE `inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventorymovements`
--

DROP TABLE IF EXISTS `inventorymovements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventorymovements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` enum('IN','OUT','ADJUST','RETURN','CANCEL_PURCHASE','BREAK_PACK','RE_PACK') NOT NULL,
  `previous` int NOT NULL,
  `new` int NOT NULL,
  `quantity` int NOT NULL,
  `reference` int NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int DEFAULT NULL,
  `combinationId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  KEY `combinationId` (`combinationId`),
  CONSTRAINT `inventorymovements_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `inventorymovements_ibfk_2` FOREIGN KEY (`combinationId`) REFERENCES `productcombinations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventorymovements`
--

LOCK TABLES `inventorymovements` WRITE;
/*!40000 ALTER TABLE `inventorymovements` DISABLE KEYS */;
INSERT INTO `inventorymovements` VALUES (1,'BREAK_PACK',10,8,2,1,'Break pack','2025-08-16 00:28:01','2025-08-16 00:28:01',1,1),(2,'RE_PACK',0,24,24,1,'Repack','2025-08-16 00:28:01','2025-08-16 00:28:01',1,5),(3,'BREAK_PACK',5,2,3,4,'Break pack','2025-08-16 06:55:38','2025-08-16 06:55:38',1,4),(4,'RE_PACK',0,36,36,4,'Repack','2025-08-16 06:55:38','2025-08-16 06:55:38',1,8);
/*!40000 ALTER TABLE `inventorymovements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderstatushistories`
--

DROP TABLE IF EXISTS `orderstatushistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderstatushistories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchaseOrderId` int DEFAULT NULL,
  `salesOrderId` int DEFAULT NULL,
  `status` enum('PENDING','RECEIVED','COMPLETED','CANCELLED') DEFAULT NULL,
  `changedBy` int DEFAULT NULL,
  `changedAt` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchaseOrderId` (`purchaseOrderId`),
  KEY `salesOrderId` (`salesOrderId`),
  KEY `changedBy` (`changedBy`),
  CONSTRAINT `orderstatushistories_ibfk_1` FOREIGN KEY (`purchaseOrderId`) REFERENCES `purchaseorders` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `orderstatushistories_ibfk_2` FOREIGN KEY (`salesOrderId`) REFERENCES `salesorders` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `orderstatushistories_ibfk_3` FOREIGN KEY (`changedBy`) REFERENCES `users` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderstatushistories`
--

LOCK TABLES `orderstatushistories` WRITE;
/*!40000 ALTER TABLE `orderstatushistories` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderstatushistories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productcombinations`
--

DROP TABLE IF EXISTS `productcombinations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productcombinations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `productId` int DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `reorderLevel` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  KEY `productId` (`productId`),
  CONSTRAINT `productcombinations_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productcombinations`
--

LOCK TABLES `productcombinations` WRITE;
/*!40000 ALTER TABLE `productcombinations` DISABLE KEYS */;
INSERT INTO `productcombinations` VALUES (1,1,'01|TSH|BOX|S|RED',100.00,NULL,'2025-08-15 23:35:54','2025-08-15 23:35:54',NULL),(2,1,'01|TSH|BOX|S|BLU',120.00,NULL,'2025-08-15 23:35:54','2025-08-15 23:35:54',NULL),(3,1,'01|TSH|BOX|M|RED',80.00,NULL,'2025-08-15 23:35:54','2025-08-15 23:35:54',NULL),(4,1,'01|TSH|BOX|M|BLU',50.00,NULL,'2025-08-15 23:35:54','2025-08-15 23:35:54',NULL),(5,2,'01|TSH|PCS|S|RED',0.00,NULL,'2025-08-15 23:40:13','2025-08-15 23:40:13',NULL),(6,2,'01|TSH|PCS|S|BLU',0.00,NULL,'2025-08-15 23:40:13','2025-08-15 23:40:13',NULL),(7,2,'01|TSH|PCS|M|RED',0.00,NULL,'2025-08-15 23:40:13','2025-08-15 23:40:13',NULL),(8,2,'01|TSH|PCS|M|BLU',0.00,NULL,'2025-08-15 23:40:13','2025-08-15 23:40:13',NULL);
/*!40000 ALTER TABLE `productcombinations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text,
  `unit` varchar(255) NOT NULL,
  `categoryId` int NOT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `conversionFactor` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_name_unit` (`name`,`unit`),
  KEY `categoryId` (`categoryId`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'T-Shirt','Cotton T-Shirt','BOX',1,'01|TSH',12,'2025-08-15 23:35:54','2025-08-16 00:27:51',NULL),(2,'T-Shirt','Cotton T-Shirt','PCS',1,'01|TSH',NULL,'2025-08-15 23:40:13','2025-08-15 23:40:13',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchaseorderitems`
--

DROP TABLE IF EXISTS `purchaseorderitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaseorderitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchaseOrderId` int DEFAULT NULL,
  `combinationId` int DEFAULT NULL,
  `quantity` int DEFAULT '0',
  `originalPrice` decimal(10,2) DEFAULT '0.00',
  `purchasePrice` decimal(10,2) DEFAULT '0.00',
  `totalAmount` decimal(10,2) DEFAULT '0.00',
  `discount` decimal(10,2) DEFAULT '0.00',
  `unit` varchar(255) DEFAULT NULL,
  `discountNote` text,
  `skuSnapshot` varchar(255) DEFAULT NULL,
  `nameSnapshot` varchar(255) DEFAULT NULL,
  `categorySnapshot` json DEFAULT NULL,
  `variantSnapshot` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchaseOrderId` (`purchaseOrderId`),
  KEY `combinationId` (`combinationId`),
  CONSTRAINT `purchaseorderitems_ibfk_1` FOREIGN KEY (`purchaseOrderId`) REFERENCES `purchaseorders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `purchaseorderitems_ibfk_2` FOREIGN KEY (`combinationId`) REFERENCES `productcombinations` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaseorderitems`
--

LOCK TABLES `purchaseorderitems` WRITE;
/*!40000 ALTER TABLE `purchaseorderitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchaseorderitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchaseorders`
--

DROP TABLE IF EXISTS `purchaseorders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaseorders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchaseOrderNumber` varchar(255) NOT NULL,
  `supplierId` int NOT NULL,
  `status` enum('PENDING','RECEIVED','COMPLETED','CANCELLED') DEFAULT 'PENDING',
  `deliveryDate` datetime DEFAULT NULL,
  `cancellationReason` text,
  `totalAmount` decimal(10,2) NOT NULL,
  `notes` text,
  `internalNotes` text,
  `modeOfPayment` enum('CASH','CHECK') DEFAULT 'CHECK',
  `checkNumber` varchar(255) DEFAULT NULL,
  `dueDate` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `purchaseOrderNumber` (`purchaseOrderNumber`),
  UNIQUE KEY `checkNumber` (`checkNumber`),
  KEY `supplierId` (`supplierId`),
  CONSTRAINT `purchaseorders_ibfk_1` FOREIGN KEY (`supplierId`) REFERENCES `suppliers` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaseorders`
--

LOCK TABLES `purchaseorders` WRITE;
/*!40000 ALTER TABLE `purchaseorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchaseorders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salesorderitems`
--

DROP TABLE IF EXISTS `salesorderitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salesorderitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `salesOrderId` int DEFAULT NULL,
  `combinationId` int DEFAULT NULL,
  `quantity` int DEFAULT '0',
  `originalPrice` decimal(10,2) DEFAULT '0.00',
  `purchasePrice` decimal(10,2) DEFAULT '0.00',
  `totalAmount` decimal(10,2) DEFAULT '0.00',
  `discount` decimal(10,2) DEFAULT '0.00',
  `unit` varchar(255) DEFAULT NULL,
  `discountNote` text,
  `skuSnapshot` varchar(255) DEFAULT NULL,
  `nameSnapshot` varchar(255) DEFAULT NULL,
  `categorySnapshot` json DEFAULT NULL,
  `variantSnapshot` json DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `inventoryId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `salesOrderId` (`salesOrderId`),
  KEY `combinationId` (`combinationId`),
  KEY `inventoryId` (`inventoryId`),
  CONSTRAINT `salesorderitems_ibfk_1` FOREIGN KEY (`salesOrderId`) REFERENCES `salesorders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `salesorderitems_ibfk_2` FOREIGN KEY (`combinationId`) REFERENCES `productcombinations` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `salesorderitems_ibfk_3` FOREIGN KEY (`inventoryId`) REFERENCES `inventories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salesorderitems`
--

LOCK TABLES `salesorderitems` WRITE;
/*!40000 ALTER TABLE `salesorderitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `salesorderitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salesorders`
--

DROP TABLE IF EXISTS `salesorders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salesorders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `salesOrderNumber` varchar(255) NOT NULL,
  `customerId` int NOT NULL,
  `status` enum('PENDING','RECEIVED','COMPLETED','CANCELLED') DEFAULT 'PENDING',
  `orderDate` datetime DEFAULT NULL,
  `isDelivery` tinyint(1) DEFAULT NULL,
  `isDeliveryCompleted` tinyint(1) DEFAULT NULL,
  `deliveryAddress` text,
  `deliveryInstructions` text,
  `deliveryDate` datetime DEFAULT NULL,
  `cancellationReason` text,
  `totalAmount` decimal(10,2) NOT NULL,
  `notes` text,
  `internalNotes` text,
  `modeOfPayment` enum('CASH','CHECK') DEFAULT 'CASH',
  `checkNumber` varchar(255) DEFAULT NULL,
  `dueDate` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `salesOrderNumber` (`salesOrderNumber`),
  UNIQUE KEY `checkNumber` (`checkNumber`),
  KEY `customerId` (`customerId`),
  CONSTRAINT `salesorders_ibfk_1` FOREIGN KEY (`customerId`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salesorders`
--

LOCK TABLES `salesorders` WRITE;
/*!40000 ALTER TABLE `salesorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `salesorders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequelizemeta`
--

DROP TABLE IF EXISTS `sequelizemeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequelizemeta` (
  `name` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequelizemeta`
--

LOCK TABLES `sequelizemeta` WRITE;
/*!40000 ALTER TABLE `sequelizemeta` DISABLE KEYS */;
INSERT INTO `sequelizemeta` VALUES ('20250815024756_init.js'),('20250815063815-break-pack.js');
/*!40000 ALTER TABLE `sequelizemeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` text,
  `address` varchar(255) NOT NULL,
  `notes` text,
  `isActive` tinyint(1) DEFAULT '1',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'Eayo','Tomasina Wanden','twanden0@npr.org','839-265-9013','93872 Graceland Alley',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(2,'Skiptube','Ansley Perfili','aperfili1@phoca.cz','794-145-3624','830 Harper Street',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(3,'Buzzbean','Melesa Clyde','mclyde2@ox.ac.uk','189-755-3180','9 Glendale Plaza',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(4,'Twinte','Nita Beardall','nbeardall3@redcross.org','888-338-9394','61 Stuart Crossing',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(5,'Riffpath','Stacia Benko','sbenko4@uiuc.edu','483-879-5016','0982 Bay Road',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(6,'Twitterwire','Sheeree Poulston','spoulston5@accuweather.com','535-912-8960','08 Iowa Plaza',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(7,'Roombo','Leland Borrows','lborrows6@google.co.jp','837-604-9075','89625 Melody Point',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(8,'Gabtype','Cornelius Conniam','cconniam7@mac.com','676-350-3045','06762 Fisk Place',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(9,'Yacero','Sam Dallinder','sdallinder8@over-blog.com','602-534-5164','5181 Warner Crossing',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(10,'Viva','Karin Bassick','kbassick9@mayoclinic.com','840-109-5123','6 Westport Lane',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(11,'Wordpedia','Nyssa Woodvine','nwoodvinea@stumbleupon.com','751-948-0201','7740 Amoth Terrace',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(12,'Kimia','Daune Winnard','dwinnardb@freewebs.com','960-824-3857','5940 Pleasure Trail',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(13,'Zoombeat','Alejandrina Dumbell','adumbellc@blog.com','402-202-5555','14007 Lukken Avenue',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(14,'Fivebridge','Annissa Burborough','aburboroughd@howstuffworks.com','611-501-8783','054 Susan Point',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(15,'Buzzbean','Rhianna Filippone','rfilipponee@mayoclinic.com','910-831-8353','41 Dakota Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(16,'Edgeify','Hernando Huncoot','hhuncootf@goo.ne.jp','559-597-9052','6156 Hoepker Road',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(17,'Gabtype','Barby Witherspoon','bwitherspoong@barnesandnoble.com','908-872-6376','44859 Pennsylvania Parkway',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(18,'Aimbo','Conan Tzarkov','ctzarkovh@ftc.gov','675-455-2222','8 Annamark Hill',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(19,'Photobug','Elora Simonassi','esimonassii@salon.com','329-696-2294','2038 Monterey Avenue',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(20,'Twimbo','Addia Carnall','acarnallj@sogou.com','302-508-3446','2679 Di Loreto Alley',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(21,'Tambee','Nanine Pallent','npallentk@ox.ac.uk','673-764-6971','98 Canary Hill',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(22,'Kamba','Paco Abdee','pabdeel@blogger.com','603-717-6862','84 Southridge Pass',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(23,'Tagcat','Taffy Addekin','taddekinm@bbb.org','254-848-5434','09868 Gerald Point',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(24,'Centizu','Levon Keller','lkellern@w3.org','642-210-7759','1717 Vidon Plaza',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(25,'Bubblemix','Gweneth Staniforth','gstanifortho@archive.org','857-465-5011','198 Novick Trail',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(26,'Rooxo','Cyb McCraw','cmccrawp@behance.net','864-137-9649','68431 Dixon Alley',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(27,'Jetpulse','Amandy Musgrove','amusgroveq@webs.com','903-962-2962','8 Upham Avenue',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(28,'Edgeify','Orv Poli','opolir@illinois.edu','797-878-8025','47592 Scott Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(29,'Mynte','Norean Duly','ndulys@hibu.com','312-986-5488','784 Blaine Lane',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(30,'Topiclounge','Valma Chatten','vchattent@slashdot.org','558-343-9322','40740 Grayhawk Point',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(31,'Topiczoom','Chaim Dunniom','cdunniomu@mediafire.com','981-505-9626','02272 Raven Street',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(32,'Yacero','Grange Tinton','gtintonv@quantcast.com','163-752-0363','84293 Warbler Hill',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(33,'Ailane','Franny Godfery','fgodferyw@e-recht24.de','398-548-7737','712 Shoshone Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(34,'Kayveo','Alane Robertacci','arobertaccix@nps.gov','502-324-2248','718 Elmside Point',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(35,'Realcube','Barnaby Menel','bmenely@rakuten.co.jp','470-406-2420','3724 Arrowood Point',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(36,'Rooxo','Enrichetta Dyers','edyersz@usgs.gov','129-149-7310','740 Nobel Junction',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(37,'Einti','Alanna Maycock','amaycock10@answers.com','529-212-6664','04451 Park Meadow Park',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(38,'Edgepulse','Giulietta Doulton','gdoulton11@twitpic.com','429-880-9325','84 Oak Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(39,'Voolith','Dolph Gruby','dgruby12@miitbeian.gov.cn','303-138-9917','0 Corben Street',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(40,'Thoughtworks','Lucie Freestone','lfreestone13@si.edu','431-767-1703','76628 Talmadge Avenue',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(41,'Divape','Ransell Bricham','rbricham14@paginegialle.it','805-297-5156','7 South Avenue',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(42,'Dablist','Rita Symson','rsymson15@mapquest.com','619-607-5503','9 Continental Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(43,'Flipstorm','Joellen Kyle','jkyle16@de.vu','593-477-4720','7 Longview Hill',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(44,'Tazz','Caddric Nobes','cnobes17@icio.us','999-252-6725','4277 Randy Trail',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(45,'Gabcube','Creight Guidera','cguidera18@google.com','791-849-4174','68 Rusk Road',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(46,'Blognation','Retha Ketton','rketton19@i2i.jp','772-345-3239','02979 Victoria Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(47,'Buzzdog','Naomi Incogna','nincogna1a@360.cn','874-477-4357','0 Fuller Hill',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(48,'Skippad','Broderick Flannigan','bflannigan1b@macromedia.com','907-213-3067','582 Loomis Terrace',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(49,'Trilia','Roberta Mallall','rmallall1c@nhs.uk','699-639-3816','86548 Brown Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(50,'Yoveo','Jada Malham','jmalham1d@google.pl','765-918-2498','8 Bartelt Junction',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(51,'Twitterbridge','Fidela Gascone','fgascone1e@yale.edu','434-919-7166','6 Prairie Rose Street',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(52,'Zooveo','Babbie Impy','bimpy1f@furl.net','536-332-7950','578 Laurel Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(53,'Linklinks','Aidan McCreadie','amccreadie1g@va.gov','216-636-2362','47 Sundown Lane',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(54,'Oyoyo','Melessa Tague','mtague1h@archive.org','879-762-3671','95 Montana Junction',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(55,'Fiveclub','Garrot Louth','glouth1i@army.mil','822-931-4540','3 Mariners Cove Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(56,'JumpXS','Lotte Vinnick','lvinnick1j@kickstarter.com','854-249-6169','39682 Porter Point',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(57,'Jatri','Cherye Dowry','cdowry1k@dion.ne.jp','219-541-2756','28029 Northport Parkway',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(58,'Yodo','Lib Emmett','lemmett1l@alibaba.com','749-819-5967','2 Northridge Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(59,'Oozz','Salomo Ruskin','sruskin1m@google.pl','415-258-1870','325 Dryden Circle',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(60,'Photolist','Randie Goodered','rgoodered1n@cnn.com','542-778-6416','3179 Mallory Plaza',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(61,'Shuffledrive','Natty Lerohan','nlerohan1o@irs.gov','952-275-4160','490 Mitchell Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(62,'Cogidoo','Matt Vause','mvause1p@abc.net.au','626-724-3325','16468 Heffernan Hill',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(63,'Flipopia','Ivor Destouche','idestouche1q@spotify.com','332-676-1985','432 Gateway Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(64,'Zoomdog','Rees Ganiford','rganiford1r@discovery.com','626-805-4472','5910 Jana Place',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(65,'Avamba','Nels Amor','namor1s@webnode.com','583-382-6420','97278 Northwestern Court',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(66,'Plajo','Giustino Shay','gshay1t@miibeian.gov.cn','433-634-4103','51 Northland Avenue',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(67,'Muxo','Ruperta Caldecourt','rcaldecourt1u@mozilla.org','480-311-2036','76 Melody Court',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(68,'Ooba','Mari Pietron','mpietron1v@rakuten.co.jp','525-786-5218','706 Reindahl Circle',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(69,'Yambee','Carmelita Stonestreet','cstonestreet1w@virginia.edu','860-974-8897','2812 Orin Street',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(70,'Jayo','Johnnie Headingham','jheadingham1x@google.cn','462-393-6963','4177 Gerald Park',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(71,'Kwilith','Petra Millett','pmillett1y@technorati.com','832-320-8861','914 Hagan Pass',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(72,'Realmix','Caroline Culpen','cculpen1z@addthis.com','504-212-6399','11 Aberg Alley',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(73,'Babbleblab','Joe MacHostie','jmachostie20@independent.co.uk','508-726-1645','09 Arizona Circle',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(74,'Skyndu','Randee Noton','rnoton21@economist.com','625-171-7557','0358 Independence Terrace',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(75,'Buzzshare','Celeste Steuart','csteuart22@theatlantic.com','533-613-5437','76381 Cardinal Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(76,'Demimbu','Natassia Crotty','ncrotty23@home.pl','419-476-9313','353 Ohio Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(77,'Kimia','Dugald Bleby','dbleby24@utexas.edu','369-790-5073','06577 Southridge Drive',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(78,'Wikizz','Garrik Salzen','gsalzen25@photobucket.com','120-881-7209','8 Brentwood Crossing',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(79,'Plambee','Friederike Bew','fbew26@go.com','445-723-2557','2 Prentice Hill',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(80,'Skinder','Harmonia Barks','hbarks27@printfriendly.com','171-185-2766','3382 Dottie Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(81,'Abata','Windy Gratrix','wgratrix28@jiathis.com','904-659-1179','2575 Division Drive',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(82,'Flipbug','Isador Connerry','iconnerry29@parallels.com','542-640-3398','90282 Lillian Avenue',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(83,'Layo','Marleen Landsberg','mlandsberg2a@google.co.jp','628-413-7681','3 Dunning Drive',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(84,'Aibox','Lana Knock','lknock2b@blinklist.com','946-984-3844','42010 Eastlawn Trail',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(85,'Kimia','Phillipe Klewi','pklewi2c@weebly.com','404-466-1201','471 Sherman Court',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(86,'Kwimbee','Thomasin Kinkaid','tkinkaid2d@epa.gov','513-777-4063','7 Reindahl Court',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(87,'Quinu','Nicolette Wrathmell','nwrathmell2e@flickr.com','167-863-1392','37 Vahlen Trail',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(88,'Ooba','Tamarah Stelfax','tstelfax2f@tinyurl.com','574-739-8312','86814 Mayer Road',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(89,'Skiptube','Kinny Clarkson','kclarkson2g@nydailynews.com','939-231-3107','65194 Mcguire Drive',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(90,'Yabox','Cornie Goodsal','cgoodsal2h@yolasite.com','731-631-2135','900 Lukken Terrace',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(91,'Einti','Ange Quillinane','aquillinane2i@gmpg.org','984-187-9747','803 Bluejay Lane',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(92,'Bubbletube','Fannie Tremmel','ftremmel2j@imageshack.us','541-483-4758','13399 Sutteridge Lane',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(93,'Flipstorm','Jud Johncey','jjohncey2k@facebook.com','830-459-5696','23 Brown Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(94,'Browsebug','Erskine Boothman','eboothman2l@chron.com','783-175-1133','2 4th Center',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(95,'Quaxo','Valentijn Gheeraert','vgheeraert2m@icq.com','359-608-7545','51684 Scott Parkway',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(96,'Realmix','Jasen Daborn','jdaborn2n@moonfruit.com','736-410-3591','4589 Golf View Parkway',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(97,'Oozz','Dulci Connaughton','dconnaughton2o@wordpress.com','484-998-1984','6026 Carberry Trail',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(98,'Photofeed','Georg Vinten','gvinten2p@tamu.edu','260-968-9805','25612 Forest Place',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(99,'Meembee','Raphaela Eadon','readon2q@mtv.com','789-549-0423','0780 Transport Way',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(100,'Trunyx','Renell Huriche','rhuriche2r@oracle.com','768-588-4335','1 Hansons Junction',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `isActive` tinyint(1) DEFAULT '0',
  `isAdmin` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `deletedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Joel Carlos','killerbytes','joelcarlos02@gmail.com','$2b$08$tDiVoSPgMR5acijj9jQMiOoNfPcG4kx3h62zEHjCjPRQV5vryM48a',1,0,'2025-08-15 23:35:54','2025-08-15 23:35:54',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `varianttypes`
--

DROP TABLE IF EXISTS `varianttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `varianttypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `productId` int DEFAULT NULL,
  `isTemplate` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `productId` (`productId`),
  CONSTRAINT `varianttypes_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `varianttypes`
--

LOCK TABLES `varianttypes` WRITE;
/*!40000 ALTER TABLE `varianttypes` DISABLE KEYS */;
INSERT INTO `varianttypes` VALUES (1,'Size',1,NULL,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(2,'Color',1,NULL,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(16,'NAIL_SIZES',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(17,'PAINT_COLORS',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(18,'PAINT_SIZES',NULL,1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(19,'Color',2,NULL,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(20,'Size',2,NULL,'2025-08-15 23:40:13','2025-08-15 23:40:13');
/*!40000 ALTER TABLE `varianttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variantvalues`
--

DROP TABLE IF EXISTS `variantvalues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variantvalues` (
  `id` int NOT NULL AUTO_INCREMENT,
  `value` varchar(255) DEFAULT NULL,
  `variantTypeId` int DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `variantTypeId` (`variantTypeId`),
  CONSTRAINT `variantvalues_ibfk_1` FOREIGN KEY (`variantTypeId`) REFERENCES `varianttypes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variantvalues`
--

LOCK TABLES `variantvalues` WRITE;
/*!40000 ALTER TABLE `variantvalues` DISABLE KEYS */;
INSERT INTO `variantvalues` VALUES (1,'S',1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(2,'M',1,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(3,'Red',2,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(4,'Blue',2,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(34,'1/4\"',16,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(35,'1/2\"',16,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(36,'3/8\"',16,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(37,'1\"',16,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(38,'Yellow 1',17,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(39,'Violet 2',17,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(40,'White 3',17,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(41,'Black 4',17,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(42,'1 Gallon',18,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(43,'1 Liter',18,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(44,'1/2 Liter',18,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(45,'4\"',16,'2025-08-15 23:35:54','2025-08-15 23:35:54'),(46,'Red',19,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(47,'Blue',19,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(48,'S',20,'2025-08-15 23:40:13','2025-08-15 23:40:13'),(49,'M',20,'2025-08-15 23:40:13','2025-08-15 23:40:13');
/*!40000 ALTER TABLE `variantvalues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-16 19:39:01
