--
-- PostgreSQL database dump
--

\restrict x7rGr1kTcNsB0ZRCDK2eWVkrzvVVb6443KoGb9TpXAh9cavyRJsH9HGINhYbx4N

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: Categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Categories" (id, name, description, "order", "deletedAt") FROM stdin;
1	Building Materials	Foundation materials including lumber, plywood, concrete, roofing, siding, insulation, drywall, and fencing	1	\N
2	Hardware	Essential small parts like fasteners (nails, screws), tools accessories, door/window/cabinet hardware, chains, and electrical boxes	2	\N
3	Paint & Supplies	Interior/exterior paint, stains, spray paint, brushes, rollers, tape, wallpaper, and painting preparation materials	3	\N
4	Tools	Power tools (drills, saws), hand tools (hammers, wrenches), tool storage, and outdoor power equipment (mowers, trimmers)	4	\N
5	Plumbing	Water systems components including pipes, fittings, water heaters, faucets, sinks, sump pumps, and toilets	\N	\N
6	Electrical	Power and lighting systems with wiring, breakers, switches, outlets, lighting fixtures, ceiling fans, and generators	\N	\N
7	Flooring	Surface coverings like carpet, hardwood, laminate, vinyl, tile, underlayment, and area rugs	\N	\N
8	Kitchen & Bath	Renovation essentials including cabinets, countertops, sinks, faucets, vanities, bathtubs, showers, and toilets	\N	\N
9	Doors & Windows	Interior/exterior doors, various window types, and garage doors for entryways and natural light	\N	\N
10	Garden Center	Plants (trees/shrubs/flowers), soil, mulch, fertilizer, gardening tools, and pest control for landscaping	\N	\N
\.


--
-- Data for Name: Products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Products" (id, name, description, unit, "categoryId", sku, "conversionFactor", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Shovel	\N	PCS	4	04|SHO	\N	2025-08-21 11:07:55.859+08	2025-08-21 11:07:55.859+08	\N
2	Shovel Steel Frame & Handle	\N	PCS	4	04|SHO_STE_FR	\N	2025-08-21 11:14:41.981+08	2025-08-21 11:14:41.981+08	\N
\.


--
-- Data for Name: ProductCombinations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductCombinations" (id, "productId", name, sku, price, "reorderLevel", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	1	Shovel - Spade	04|SHO|PCS|SPA	115.00	10	2025-08-21 11:08:31.469+08	2025-08-21 11:08:31.469+08	\N
2	1	Shovel - Square	04|SHO|PCS|SQU	115.00	10	2025-08-21 11:08:31.482+08	2025-08-21 11:08:31.482+08	\N
3	2	Shovel Steel Frame & Handle - Spade	04|SHO_STE_FR|PCS|SPA	170.00	10	2025-08-21 11:15:12.382+08	2025-08-21 11:15:12.382+08	\N
4	2	Shovel Steel Frame & Handle - Square	04|SHO_STE_FR|PCS|SQU	170.00	10	2025-08-21 11:15:12.391+08	2025-08-21 11:15:12.391+08	\N
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (id, name, username, email, password, "isActive", "isAdmin", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Joel Carlos	killerbytes	joelcarlos02@gmail.com	$2b$08$c.Xkrs4/RZkHTADSYw800u1eMzdbFg5sHg/1N3O6loky6il6l6zuG	t	f	2025-08-21 11:06:37.102+08	2025-08-21 11:06:37.102+08	\N
\.


--
-- Data for Name: BreakPacks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BreakPacks" (id, "fromCombinationId", "toCombinationId", quantity, "conversionFactor", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: VariantTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VariantTypes" (id, name, "productId", "isTemplate", "createdAt", "updatedAt") FROM stdin;
1	Type	1	\N	2025-08-21 11:08:10.679+08	2025-08-21 11:08:10.679+08
2	Type	2	\N	2025-08-21 11:14:56.93+08	2025-08-21 11:14:56.93+08
\.


--
-- Data for Name: VariantValues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VariantValues" (id, value, "variantTypeId", "createdAt", "updatedAt") FROM stdin;
1	Spade	1	2025-08-21 11:08:10.681+08	2025-08-21 11:08:10.681+08
2	Square	1	2025-08-21 11:08:10.683+08	2025-08-21 11:08:10.683+08
3	Spade	2	2025-08-21 11:14:56.934+08	2025-08-21 11:14:56.934+08
4	Square	2	2025-08-21 11:14:56.937+08	2025-08-21 11:14:56.937+08
\.


--
-- Data for Name: CombinationValues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CombinationValues" ("combinationId", "variantValueId", "createdAt", "updatedAt") FROM stdin;
1	1	2025-08-21 11:08:31.473+08	2025-08-21 11:08:31.473+08
2	2	2025-08-21 11:08:31.484+08	2025-08-21 11:08:31.484+08
3	3	2025-08-21 11:15:12.384+08	2025-08-21 11:15:12.384+08
4	4	2025-08-21 11:15:12.392+08	2025-08-21 11:15:12.392+08
\.


--
-- Data for Name: Customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customers" (id, name, email, phone, address, notes, "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	User	\N	\N	Unknown	\N	t	2025-08-21 11:06:37.084+08	2025-08-21 11:06:37.084+08	\N
\.


--
-- Data for Name: Inventories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Inventories" (id, "combinationId", quantity, "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	1	0	2025-08-21 11:08:31.475+08	2025-08-21 11:08:31.475+08	\N
2	2	0	2025-08-21 11:08:31.486+08	2025-08-21 11:08:31.486+08	\N
3	3	0	2025-08-21 11:15:12.386+08	2025-08-21 11:15:12.386+08	\N
4	4	0	2025-08-21 11:15:12.394+08	2025-08-21 11:15:12.394+08	\N
\.


--
-- Data for Name: InventoryBreakPacks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InventoryBreakPacks" (id, "fromCombinationId", "toCombinationId", "fromQuantity", "toQuantity", reason, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockAdjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StockAdjustments" (id, "referenceNo", "combinationId", "systemQuantity", "newQuantity", difference, reason, notes, "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: InventoryMovements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InventoryMovements" (id, type, previous, new, quantity, reference, reason, "createdAt", "updatedAt", "userId", "combinationId", "referenceId") FROM stdin;
\.


--
-- Data for Name: Suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Suppliers" (id, name, contact, email, phone, address, notes, "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Eayo	Tomasina Wanden	twanden0@npr.org	839-265-9013	93872 Graceland Alley	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
2	Skiptube	Ansley Perfili	aperfili1@phoca.cz	794-145-3624	830 Harper Street	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
3	Buzzbean	Melesa Clyde	mclyde2@ox.ac.uk	189-755-3180	9 Glendale Plaza	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
4	Twinte	Nita Beardall	nbeardall3@redcross.org	888-338-9394	61 Stuart Crossing	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
5	Riffpath	Stacia Benko	sbenko4@uiuc.edu	483-879-5016	0982 Bay Road	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
6	Twitterwire	Sheeree Poulston	spoulston5@accuweather.com	535-912-8960	08 Iowa Plaza	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
7	Roombo	Leland Borrows	lborrows6@google.co.jp	837-604-9075	89625 Melody Point	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
8	Gabtype	Cornelius Conniam	cconniam7@mac.com	676-350-3045	06762 Fisk Place	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
9	Yacero	Sam Dallinder	sdallinder8@over-blog.com	602-534-5164	5181 Warner Crossing	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
10	Viva	Karin Bassick	kbassick9@mayoclinic.com	840-109-5123	6 Westport Lane	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
11	Wordpedia	Nyssa Woodvine	nwoodvinea@stumbleupon.com	751-948-0201	7740 Amoth Terrace	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
12	Kimia	Daune Winnard	dwinnardb@freewebs.com	960-824-3857	5940 Pleasure Trail	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
13	Zoombeat	Alejandrina Dumbell	adumbellc@blog.com	402-202-5555	14007 Lukken Avenue	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
14	Fivebridge	Annissa Burborough	aburboroughd@howstuffworks.com	611-501-8783	054 Susan Point	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
15	Buzzbean	Rhianna Filippone	rfilipponee@mayoclinic.com	910-831-8353	41 Dakota Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
16	Edgeify	Hernando Huncoot	hhuncootf@goo.ne.jp	559-597-9052	6156 Hoepker Road	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
17	Gabtype	Barby Witherspoon	bwitherspoong@barnesandnoble.com	908-872-6376	44859 Pennsylvania Parkway	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
18	Aimbo	Conan Tzarkov	ctzarkovh@ftc.gov	675-455-2222	8 Annamark Hill	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
19	Photobug	Elora Simonassi	esimonassii@salon.com	329-696-2294	2038 Monterey Avenue	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
20	Twimbo	Addia Carnall	acarnallj@sogou.com	302-508-3446	2679 Di Loreto Alley	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
21	Tambee	Nanine Pallent	npallentk@ox.ac.uk	673-764-6971	98 Canary Hill	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
22	Kamba	Paco Abdee	pabdeel@blogger.com	603-717-6862	84 Southridge Pass	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
23	Tagcat	Taffy Addekin	taddekinm@bbb.org	254-848-5434	09868 Gerald Point	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
24	Centizu	Levon Keller	lkellern@w3.org	642-210-7759	1717 Vidon Plaza	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
25	Bubblemix	Gweneth Staniforth	gstanifortho@archive.org	857-465-5011	198 Novick Trail	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
26	Rooxo	Cyb McCraw	cmccrawp@behance.net	864-137-9649	68431 Dixon Alley	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
27	Jetpulse	Amandy Musgrove	amusgroveq@webs.com	903-962-2962	8 Upham Avenue	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
28	Edgeify	Orv Poli	opolir@illinois.edu	797-878-8025	47592 Scott Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
29	Mynte	Norean Duly	ndulys@hibu.com	312-986-5488	784 Blaine Lane	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
30	Topiclounge	Valma Chatten	vchattent@slashdot.org	558-343-9322	40740 Grayhawk Point	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
31	Topiczoom	Chaim Dunniom	cdunniomu@mediafire.com	981-505-9626	02272 Raven Street	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
32	Yacero	Grange Tinton	gtintonv@quantcast.com	163-752-0363	84293 Warbler Hill	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
33	Ailane	Franny Godfery	fgodferyw@e-recht24.de	398-548-7737	712 Shoshone Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
34	Kayveo	Alane Robertacci	arobertaccix@nps.gov	502-324-2248	718 Elmside Point	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
35	Realcube	Barnaby Menel	bmenely@rakuten.co.jp	470-406-2420	3724 Arrowood Point	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
36	Rooxo	Enrichetta Dyers	edyersz@usgs.gov	129-149-7310	740 Nobel Junction	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
37	Einti	Alanna Maycock	amaycock10@answers.com	529-212-6664	04451 Park Meadow Park	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
38	Edgepulse	Giulietta Doulton	gdoulton11@twitpic.com	429-880-9325	84 Oak Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
39	Voolith	Dolph Gruby	dgruby12@miitbeian.gov.cn	303-138-9917	0 Corben Street	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
40	Thoughtworks	Lucie Freestone	lfreestone13@si.edu	431-767-1703	76628 Talmadge Avenue	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
41	Divape	Ransell Bricham	rbricham14@paginegialle.it	805-297-5156	7 South Avenue	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
42	Dablist	Rita Symson	rsymson15@mapquest.com	619-607-5503	9 Continental Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
43	Flipstorm	Joellen Kyle	jkyle16@de.vu	593-477-4720	7 Longview Hill	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
44	Tazz	Caddric Nobes	cnobes17@icio.us	999-252-6725	4277 Randy Trail	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
45	Gabcube	Creight Guidera	cguidera18@google.com	791-849-4174	68 Rusk Road	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
46	Blognation	Retha Ketton	rketton19@i2i.jp	772-345-3239	02979 Victoria Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
47	Buzzdog	Naomi Incogna	nincogna1a@360.cn	874-477-4357	0 Fuller Hill	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
48	Skippad	Broderick Flannigan	bflannigan1b@macromedia.com	907-213-3067	582 Loomis Terrace	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
49	Trilia	Roberta Mallall	rmallall1c@nhs.uk	699-639-3816	86548 Brown Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
50	Yoveo	Jada Malham	jmalham1d@google.pl	765-918-2498	8 Bartelt Junction	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
51	Twitterbridge	Fidela Gascone	fgascone1e@yale.edu	434-919-7166	6 Prairie Rose Street	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
52	Zooveo	Babbie Impy	bimpy1f@furl.net	536-332-7950	578 Laurel Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
53	Linklinks	Aidan McCreadie	amccreadie1g@va.gov	216-636-2362	47 Sundown Lane	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
54	Oyoyo	Melessa Tague	mtague1h@archive.org	879-762-3671	95 Montana Junction	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
55	Fiveclub	Garrot Louth	glouth1i@army.mil	822-931-4540	3 Mariners Cove Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
56	JumpXS	Lotte Vinnick	lvinnick1j@kickstarter.com	854-249-6169	39682 Porter Point	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
57	Jatri	Cherye Dowry	cdowry1k@dion.ne.jp	219-541-2756	28029 Northport Parkway	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
58	Yodo	Lib Emmett	lemmett1l@alibaba.com	749-819-5967	2 Northridge Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
59	Oozz	Salomo Ruskin	sruskin1m@google.pl	415-258-1870	325 Dryden Circle	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
60	Photolist	Randie Goodered	rgoodered1n@cnn.com	542-778-6416	3179 Mallory Plaza	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
61	Shuffledrive	Natty Lerohan	nlerohan1o@irs.gov	952-275-4160	490 Mitchell Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
62	Cogidoo	Matt Vause	mvause1p@abc.net.au	626-724-3325	16468 Heffernan Hill	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
63	Flipopia	Ivor Destouche	idestouche1q@spotify.com	332-676-1985	432 Gateway Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
64	Zoomdog	Rees Ganiford	rganiford1r@discovery.com	626-805-4472	5910 Jana Place	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
65	Avamba	Nels Amor	namor1s@webnode.com	583-382-6420	97278 Northwestern Court	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
66	Plajo	Giustino Shay	gshay1t@miibeian.gov.cn	433-634-4103	51 Northland Avenue	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
67	Muxo	Ruperta Caldecourt	rcaldecourt1u@mozilla.org	480-311-2036	76 Melody Court	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
68	Ooba	Mari Pietron	mpietron1v@rakuten.co.jp	525-786-5218	706 Reindahl Circle	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
69	Yambee	Carmelita Stonestreet	cstonestreet1w@virginia.edu	860-974-8897	2812 Orin Street	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
70	Jayo	Johnnie Headingham	jheadingham1x@google.cn	462-393-6963	4177 Gerald Park	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
71	Kwilith	Petra Millett	pmillett1y@technorati.com	832-320-8861	914 Hagan Pass	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
72	Realmix	Caroline Culpen	cculpen1z@addthis.com	504-212-6399	11 Aberg Alley	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
73	Babbleblab	Joe MacHostie	jmachostie20@independent.co.uk	508-726-1645	09 Arizona Circle	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
74	Skyndu	Randee Noton	rnoton21@economist.com	625-171-7557	0358 Independence Terrace	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
75	Buzzshare	Celeste Steuart	csteuart22@theatlantic.com	533-613-5437	76381 Cardinal Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
76	Demimbu	Natassia Crotty	ncrotty23@home.pl	419-476-9313	353 Ohio Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
77	Kimia	Dugald Bleby	dbleby24@utexas.edu	369-790-5073	06577 Southridge Drive	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
78	Wikizz	Garrik Salzen	gsalzen25@photobucket.com	120-881-7209	8 Brentwood Crossing	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
79	Plambee	Friederike Bew	fbew26@go.com	445-723-2557	2 Prentice Hill	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
80	Skinder	Harmonia Barks	hbarks27@printfriendly.com	171-185-2766	3382 Dottie Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
81	Abata	Windy Gratrix	wgratrix28@jiathis.com	904-659-1179	2575 Division Drive	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
82	Flipbug	Isador Connerry	iconnerry29@parallels.com	542-640-3398	90282 Lillian Avenue	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
83	Layo	Marleen Landsberg	mlandsberg2a@google.co.jp	628-413-7681	3 Dunning Drive	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
84	Aibox	Lana Knock	lknock2b@blinklist.com	946-984-3844	42010 Eastlawn Trail	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
85	Kimia	Phillipe Klewi	pklewi2c@weebly.com	404-466-1201	471 Sherman Court	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
86	Kwimbee	Thomasin Kinkaid	tkinkaid2d@epa.gov	513-777-4063	7 Reindahl Court	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
87	Quinu	Nicolette Wrathmell	nwrathmell2e@flickr.com	167-863-1392	37 Vahlen Trail	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
88	Ooba	Tamarah Stelfax	tstelfax2f@tinyurl.com	574-739-8312	86814 Mayer Road	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
89	Skiptube	Kinny Clarkson	kclarkson2g@nydailynews.com	939-231-3107	65194 Mcguire Drive	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
90	Yabox	Cornie Goodsal	cgoodsal2h@yolasite.com	731-631-2135	900 Lukken Terrace	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
91	Einti	Ange Quillinane	aquillinane2i@gmpg.org	984-187-9747	803 Bluejay Lane	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
92	Bubbletube	Fannie Tremmel	ftremmel2j@imageshack.us	541-483-4758	13399 Sutteridge Lane	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
93	Flipstorm	Jud Johncey	jjohncey2k@facebook.com	830-459-5696	23 Brown Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
94	Browsebug	Erskine Boothman	eboothman2l@chron.com	783-175-1133	2 4th Center	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
95	Quaxo	Valentijn Gheeraert	vgheeraert2m@icq.com	359-608-7545	51684 Scott Parkway	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
96	Realmix	Jasen Daborn	jdaborn2n@moonfruit.com	736-410-3591	4589 Golf View Parkway	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
97	Oozz	Dulci Connaughton	dconnaughton2o@wordpress.com	484-998-1984	6026 Carberry Trail	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
98	Photofeed	Georg Vinten	gvinten2p@tamu.edu	260-968-9805	25612 Forest Place	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
99	Meembee	Raphaela Eadon	readon2q@mtv.com	789-549-0423	0780 Transport Way	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
100	Trunyx	Renell Huriche	rhuriche2r@oracle.com	768-588-4335	1 Hansons Junction	\N	t	2025-08-21 11:06:37.106+08	2025-08-21 11:06:37.106+08	\N
\.


--
-- Data for Name: PurchaseOrders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PurchaseOrders" (id, "purchaseOrderNumber", "supplierId", status, "deliveryDate", "cancellationReason", "totalAmount", notes, "internalNotes", "modeOfPayment", "checkNumber", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SalesOrders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SalesOrders" (id, "salesOrderNumber", "customerId", status, "orderDate", "isDelivery", "isDeliveryCompleted", "deliveryAddress", "deliveryInstructions", "deliveryDate", "cancellationReason", "totalAmount", notes, "internalNotes", "modeOfPayment", "checkNumber", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrderStatusHistories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderStatusHistories" (id, "purchaseOrderId", "salesOrderId", status, "changedBy", "changedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PurchaseOrderItems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PurchaseOrderItems" (id, "purchaseOrderId", "combinationId", quantity, "purchasePrice", "totalAmount", discount, "discountNote", unit, "skuSnapshot", "nameSnapshot", "categorySnapshot", "variantSnapshot", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SalesOrderItems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SalesOrderItems" (id, "salesOrderId", "combinationId", quantity, "originalPrice", "purchasePrice", "totalAmount", discount, unit, "discountNote", "skuSnapshot", "nameSnapshot", "categorySnapshot", "variantSnapshot", "createdAt", "updatedAt", "inventoryId") FROM stdin;
\.


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SequelizeMeta" (name) FROM stdin;
20250818045347_init.js
\.


--
-- Name: BreakPacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BreakPacks_id_seq"', 1, false);


--
-- Name: Categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Categories_id_seq"', 1, false);


--
-- Name: Customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Customers_id_seq"', 1, true);


--
-- Name: Inventories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Inventories_id_seq"', 4, true);


--
-- Name: InventoryBreakPacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."InventoryBreakPacks_id_seq"', 1, false);


--
-- Name: InventoryMovements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."InventoryMovements_id_seq"', 1, false);


--
-- Name: OrderStatusHistories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."OrderStatusHistories_id_seq"', 1, false);


--
-- Name: ProductCombinations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProductCombinations_id_seq"', 4, true);


--
-- Name: Products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Products_id_seq"', 2, true);


--
-- Name: PurchaseOrderItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PurchaseOrderItems_id_seq"', 1, false);


--
-- Name: PurchaseOrders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PurchaseOrders_id_seq"', 1, false);


--
-- Name: SalesOrderItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SalesOrderItems_id_seq"', 1, false);


--
-- Name: SalesOrders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SalesOrders_id_seq"', 1, false);


--
-- Name: StockAdjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StockAdjustments_id_seq"', 1, false);


--
-- Name: Suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Suppliers_id_seq"', 100, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Users_id_seq"', 1, true);


--
-- Name: VariantTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VariantTypes_id_seq"', 2, true);


--
-- Name: VariantValues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VariantValues_id_seq"', 4, true);


--
-- PostgreSQL database dump complete
--

\unrestrict x7rGr1kTcNsB0ZRCDK2eWVkrzvVVb6443KoGb9TpXAh9cavyRJsH9HGINhYbx4N

