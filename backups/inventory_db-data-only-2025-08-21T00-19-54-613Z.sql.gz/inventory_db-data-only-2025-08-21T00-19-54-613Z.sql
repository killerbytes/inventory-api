-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: inventory_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `breakpacks`
--

LOCK TABLES `breakpacks` WRITE;
/*!40000 ALTER TABLE `breakpacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `breakpacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Building Materials','Foundation materials including lumber, plywood, concrete, roofing, siding, insulation, drywall, and fencing',1,NULL),(2,'Hardware','Essential small parts like fasteners (nails, screws), tools accessories, door/window/cabinet hardware, chains, and electrical boxes',2,NULL),(3,'Paint & Supplies','Interior/exterior paint, stains, spray paint, brushes, rollers, tape, wallpaper, and painting preparation materials',3,NULL),(4,'Tools','Power tools (drills, saws), hand tools (hammers, wrenches), tool storage, and outdoor power equipment (mowers, trimmers)',4,NULL),(5,'Plumbing','Water systems components including pipes, fittings, water heaters, faucets, sinks, sump pumps, and toilets',NULL,NULL),(6,'Electrical','Power and lighting systems with wiring, breakers, switches, outlets, lighting fixtures, ceiling fans, and generators',NULL,NULL),(7,'Flooring','Surface coverings like carpet, hardwood, laminate, vinyl, tile, underlayment, and area rugs',NULL,NULL),(8,'Kitchen & Bath','Renovation essentials including cabinets, countertops, sinks, faucets, vanities, bathtubs, showers, and toilets',NULL,NULL),(9,'Doors & Windows','Interior/exterior doors, various window types, and garage doors for entryways and natural light',NULL,NULL),(10,'Garden Center','Plants (trees/shrubs/flowers), soil, mulch, fertilizer, gardening tools, and pest control for landscaping',NULL,NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `combinationvalues`
--

LOCK TABLES `combinationvalues` WRITE;
/*!40000 ALTER TABLE `combinationvalues` DISABLE KEYS */;
INSERT INTO `combinationvalues` VALUES (1,2,'2025-08-20 12:45:25','2025-08-20 12:45:25'),(2,1,'2025-08-20 12:45:25','2025-08-20 12:45:25'),(3,6,'2025-08-20 12:58:22','2025-08-20 12:58:22'),(4,5,'2025-08-20 12:58:22','2025-08-20 12:58:22'),(5,7,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(6,8,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(7,9,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(8,10,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(9,11,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(10,12,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(11,13,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(12,14,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(13,15,'2025-08-20 13:01:16','2025-08-20 13:01:16'),(14,16,'2025-08-20 13:04:31','2025-08-20 13:04:31'),(15,17,'2025-08-20 13:04:31','2025-08-20 13:04:31'),(16,18,'2025-08-20 13:11:01','2025-08-20 13:11:01'),(16,21,'2025-08-20 13:11:01','2025-08-20 13:11:01'),(17,19,'2025-08-20 13:11:01','2025-08-20 13:11:01'),(17,22,'2025-08-20 13:11:01','2025-08-20 13:11:01'),(18,20,'2025-08-20 13:11:01','2025-08-20 13:11:01'),(18,23,'2025-08-20 13:11:01','2025-08-20 13:11:01'),(19,24,'2025-08-20 13:20:32','2025-08-20 13:20:32'),(19,32,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(20,25,'2025-08-20 13:20:32','2025-08-20 13:20:32'),(20,32,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(21,26,'2025-08-20 13:20:32','2025-08-20 13:20:32'),(21,32,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(22,27,'2025-08-20 13:20:32','2025-08-20 13:20:32'),(22,32,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(23,24,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(23,33,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(24,25,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(24,33,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(25,26,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(25,33,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(26,27,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(26,33,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(27,24,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(27,34,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(28,25,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(28,34,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(29,26,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(29,34,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(30,27,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(30,34,'2025-08-20 13:51:45','2025-08-20 13:51:45'),(31,24,'2025-08-20 13:52:38','2025-08-20 13:52:38'),(31,35,'2025-08-20 13:52:38','2025-08-20 13:52:38'),(32,25,'2025-08-20 13:52:38','2025-08-20 13:52:38'),(32,35,'2025-08-20 13:52:38','2025-08-20 13:52:38'),(33,26,'2025-08-20 13:52:38','2025-08-20 13:52:38'),(33,35,'2025-08-20 13:52:38','2025-08-20 13:52:38'),(34,27,'2025-08-20 13:52:38','2025-08-20 13:52:38'),(34,35,'2025-08-20 13:52:38','2025-08-20 13:52:38');
/*!40000 ALTER TABLE `combinationvalues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'User',NULL,NULL,'Unknown',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `inventories`
--

LOCK TABLES `inventories` WRITE;
/*!40000 ALTER TABLE `inventories` DISABLE KEYS */;
INSERT INTO `inventories` VALUES (1,1,0,'2025-08-20 12:45:25','2025-08-20 12:45:25',NULL),(2,2,0,'2025-08-20 12:45:25','2025-08-20 12:45:25',NULL),(3,3,0,'2025-08-20 12:58:22','2025-08-20 12:58:22',NULL),(4,4,0,'2025-08-20 12:58:22','2025-08-20 12:58:22',NULL),(5,5,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(6,6,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(7,7,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(8,8,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(9,9,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(10,10,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(11,11,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(12,12,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(13,13,0,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(14,14,0,'2025-08-20 13:04:31','2025-08-20 13:04:31',NULL),(15,15,0,'2025-08-20 13:04:31','2025-08-20 13:04:31',NULL),(16,16,0,'2025-08-20 13:11:01','2025-08-20 13:11:01',NULL),(17,17,0,'2025-08-20 13:11:01','2025-08-20 13:11:01',NULL),(18,18,0,'2025-08-20 13:11:01','2025-08-20 13:11:01',NULL),(19,19,0,'2025-08-20 13:20:32','2025-08-20 13:20:32',NULL),(20,20,0,'2025-08-20 13:20:32','2025-08-20 13:20:32',NULL),(21,21,0,'2025-08-20 13:20:32','2025-08-20 13:20:32',NULL),(22,22,0,'2025-08-20 13:20:32','2025-08-20 13:20:32',NULL),(23,23,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(24,24,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(25,25,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(26,26,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(27,27,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(28,28,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(29,29,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(30,30,0,'2025-08-20 13:51:45','2025-08-20 13:51:45',NULL),(31,31,0,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL),(32,32,0,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL),(33,33,0,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL),(34,34,0,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL);
/*!40000 ALTER TABLE `inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `inventorybreakpacks`
--

LOCK TABLES `inventorybreakpacks` WRITE;
/*!40000 ALTER TABLE `inventorybreakpacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventorybreakpacks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `inventorymovements`
--

LOCK TABLES `inventorymovements` WRITE;
/*!40000 ALTER TABLE `inventorymovements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventorymovements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `orderstatushistories`
--

LOCK TABLES `orderstatushistories` WRITE;
/*!40000 ALTER TABLE `orderstatushistories` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderstatushistories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `productcombinations`
--

LOCK TABLES `productcombinations` WRITE;
/*!40000 ALTER TABLE `productcombinations` DISABLE KEYS */;
INSERT INTO `productcombinations` VALUES (1,1,'Shovel - Square','04|SHO|PCS|SQU',115.00,10,'2025-08-20 12:45:25','2025-08-20 12:46:04',NULL),(2,1,'Shovel - Spade','04|SHO|PCS|SPA',115.00,10,'2025-08-20 12:45:25','2025-08-20 12:46:04',NULL),(3,6,'Shovel Steel Frame & Handle - Square','04|SHO_STE_FR|PCS|SQU',170.00,10,'2025-08-20 12:58:22','2025-08-20 12:58:22',NULL),(4,6,'Shovel Steel Frame & Handle - Spade','04|SHO_STE_FR|PCS|SPA',170.00,10,'2025-08-20 12:58:22','2025-08-20 12:58:22',NULL),(5,7,'Ecolum LED Bulb DL E27 - 3w','06|ECO_LED_BU|PCS|3W',37.50,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(6,7,'Ecolum LED Bulb DL E27 - 5w','06|ECO_LED_BU|PCS|5W',43.00,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(7,7,'Ecolum LED Bulb DL E27 - 7w','06|ECO_LED_BU|PCS|7W',47.50,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(8,7,'Ecolum LED Bulb DL E27 - 9w','06|ECO_LED_BU|PCS|9W',54.50,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(9,7,'Ecolum LED Bulb DL E27 - 11w','06|ECO_LED_BU|PCS|11W',62.00,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(10,7,'Ecolum LED Bulb DL E27 - 13w','06|ECO_LED_BU|PCS|13W',73.50,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(11,7,'Ecolum LED Bulb DL E27 - 15w','06|ECO_LED_BU|PCS|15W',86.50,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(12,7,'Ecolum LED Bulb DL E27 - 17w','06|ECO_LED_BU|PCS|17W',130.00,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(13,7,'Ecolum LED Bulb DL E27 - 19w','06|ECO_LED_BU|PCS|19W',143.00,10,'2025-08-20 13:01:16','2025-08-20 13:01:16',NULL),(14,8,'Ecolum LED tube w/box type - 9w','06|ECO_LED_TU|SET|9W',150.00,10,'2025-08-20 13:04:31','2025-08-20 13:04:31',NULL),(15,8,'Ecolum LED tube w/box type - 18w','06|ECO_LED_TU|SET|18W',190.00,10,'2025-08-20 13:04:31','2025-08-20 13:04:31',NULL),(16,9,'America Panel Box - 2B | 2x2','06|AME_PAN_BO|PCS|2X2|2B',400.00,10,'2025-08-20 13:11:01','2025-08-20 13:13:44',NULL),(17,9,'America Panel Box - 4B | 3x3','06|AME_PAN_BO|PCS|3X3|4B',500.00,10,'2025-08-20 13:11:01','2025-08-20 13:13:44',NULL),(18,9,'America Panel Box - 6B | 4x4','06|AME_PAN_BO|PCS|4X4|6B',600.00,10,'2025-08-20 13:11:01','2025-08-20 13:13:44',NULL),(19,10,'GE TQL 2P Plug-in - 15A - 20A - 30A | 2P Plug-in','06|GE_TQL_2P|BOX|15A__20A',740.00,10,'2025-08-20 13:20:32','2025-08-20 13:52:38',NULL),(20,10,'GE TQL 2P Plug-in - 40A - 50A - 60A | 2P Plug-in','06|GE_TQL_2P|BOX|40A__50A',1050.00,10,'2025-08-20 13:20:32','2025-08-20 13:52:38',NULL),(21,10,'GE TQL 2P Plug-in - 70A | 2P Plug-in','06|GE_TQL_2P|BOX|70A',1525.00,10,'2025-08-20 13:20:32','2025-08-20 13:52:38',NULL),(22,10,'GE TQL 2P Plug-in - 100A | 2P Plug-in','06|GE_TQL_2P|BOX|100',1630.00,10,'2025-08-20 13:20:32','2025-08-20 13:52:38',NULL),(23,10,'GE TQL 2P Plug-in - 15A - 20A - 30A | 3P Plug-in','06|GE_TQL_2P|BOX|15A__20A|3P_PLU',1760.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(24,10,'GE TQL 2P Plug-in - 40A - 50A - 60A | 3P Plug-in','06|GE_TQL_2P|BOX|40A__50A|3P_PLU',1845.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(25,10,'GE TQL 2P Plug-in - 70A | 3P Plug-in','06|GE_TQL_2P|BOX|70A|3P_PLU',2405.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(26,10,'GE TQL 2P Plug-in - 100A | 3P Plug-in','06|GE_TQL_2P|BOX|100|3P_PLU',2765.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(27,10,'GE TQL 2P Plug-in - 15A - 20A - 30A | 2P Bolt-on','06|GE_TQL_2P|BOX|15A__20A|2P_BOL',780.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(28,10,'GE TQL 2P Plug-in - 40A - 50A - 60A | 2P Bolt-on','06|GE_TQL_2P|BOX|40A__50A|2P_BOL',890.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(29,10,'GE TQL 2P Plug-in - 70A | 2P Bolt-on','06|GE_TQL_2P|BOX|70A|2P_BOL',1545.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(30,10,'GE TQL 2P Plug-in - 100A | 2P Bolt-on','06|GE_TQL_2P|BOX|100|2P_BOL',2100.00,10,'2025-08-20 13:51:45','2025-08-20 13:52:38',NULL),(31,10,'GE TQL 2P Plug-in - 15A - 20A - 30A | 3P Bolt-on','06|GE_TQL_2P|BOX|15A__20A|3P_BOL',2440.00,10,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL),(32,10,'GE TQL 2P Plug-in - 40A - 50A - 60A | 3P Bolt-on','06|GE_TQL_2P|BOX|40A__50A|3P_BOL',2790.00,10,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL),(33,10,'GE TQL 2P Plug-in - 70A | 3P Bolt-on','06|GE_TQL_2P|BOX|70A|3P_BOL',3105.00,10,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL),(34,10,'GE TQL 2P Plug-in - 100A | 3P Bolt-on','06|GE_TQL_2P|BOX|100|3P_BOL',3470.00,10,'2025-08-20 13:52:38','2025-08-20 13:52:38',NULL);
/*!40000 ALTER TABLE `productcombinations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Shovel',NULL,'PCS',4,'04|SHO',NULL,'2025-08-20 12:44:50','2025-08-20 12:44:50',NULL),(6,'Shovel Steel Frame & Handle',NULL,'PCS',4,'04|SHO_STE_FR',NULL,'2025-08-20 12:57:19','2025-08-20 12:57:19',NULL),(7,'Ecolum LED Bulb DL E27',NULL,'PCS',6,'06|ECO_LED_BU',NULL,'2025-08-20 12:58:42','2025-08-20 12:58:42',NULL),(8,'Ecolum LED tube w/box type',NULL,'SET',6,'06|ECO_LED_TU',NULL,'2025-08-20 13:01:46','2025-08-20 13:01:46',NULL),(9,'America Panel Box',NULL,'PCS',6,'06|AME_PAN_BO',NULL,'2025-08-20 13:07:55','2025-08-20 13:07:55',NULL),(10,'GE TQL 2P Plug-in',NULL,'BOX',6,'06|GE_TQL_2P',NULL,'2025-08-20 13:18:09','2025-08-20 13:18:09',NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `purchaseorderitems`
--

LOCK TABLES `purchaseorderitems` WRITE;
/*!40000 ALTER TABLE `purchaseorderitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchaseorderitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `purchaseorders`
--

LOCK TABLES `purchaseorders` WRITE;
/*!40000 ALTER TABLE `purchaseorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchaseorders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `salesorderitems`
--

LOCK TABLES `salesorderitems` WRITE;
/*!40000 ALTER TABLE `salesorderitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `salesorderitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `salesorders`
--

LOCK TABLES `salesorders` WRITE;
/*!40000 ALTER TABLE `salesorders` DISABLE KEYS */;
/*!40000 ALTER TABLE `salesorders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `sequelizemeta`
--

LOCK TABLES `sequelizemeta` WRITE;
/*!40000 ALTER TABLE `sequelizemeta` DISABLE KEYS */;
INSERT INTO `sequelizemeta` VALUES ('20250818045347_init.js');
/*!40000 ALTER TABLE `sequelizemeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `stockadjustments`
--

LOCK TABLES `stockadjustments` WRITE;
/*!40000 ALTER TABLE `stockadjustments` DISABLE KEYS */;
/*!40000 ALTER TABLE `stockadjustments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'Eayo','Tomasina Wanden','twanden0@npr.org','839-265-9013','93872 Graceland Alley',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(2,'Skiptube','Ansley Perfili','aperfili1@phoca.cz','794-145-3624','830 Harper Street',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(3,'Buzzbean','Melesa Clyde','mclyde2@ox.ac.uk','189-755-3180','9 Glendale Plaza',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(4,'Twinte','Nita Beardall','nbeardall3@redcross.org','888-338-9394','61 Stuart Crossing',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(5,'Riffpath','Stacia Benko','sbenko4@uiuc.edu','483-879-5016','0982 Bay Road',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(6,'Twitterwire','Sheeree Poulston','spoulston5@accuweather.com','535-912-8960','08 Iowa Plaza',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(7,'Roombo','Leland Borrows','lborrows6@google.co.jp','837-604-9075','89625 Melody Point',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(8,'Gabtype','Cornelius Conniam','cconniam7@mac.com','676-350-3045','06762 Fisk Place',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(9,'Yacero','Sam Dallinder','sdallinder8@over-blog.com','602-534-5164','5181 Warner Crossing',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(10,'Viva','Karin Bassick','kbassick9@mayoclinic.com','840-109-5123','6 Westport Lane',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(11,'Wordpedia','Nyssa Woodvine','nwoodvinea@stumbleupon.com','751-948-0201','7740 Amoth Terrace',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(12,'Kimia','Daune Winnard','dwinnardb@freewebs.com','960-824-3857','5940 Pleasure Trail',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(13,'Zoombeat','Alejandrina Dumbell','adumbellc@blog.com','402-202-5555','14007 Lukken Avenue',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(14,'Fivebridge','Annissa Burborough','aburboroughd@howstuffworks.com','611-501-8783','054 Susan Point',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(15,'Buzzbean','Rhianna Filippone','rfilipponee@mayoclinic.com','910-831-8353','41 Dakota Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(16,'Edgeify','Hernando Huncoot','hhuncootf@goo.ne.jp','559-597-9052','6156 Hoepker Road',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(17,'Gabtype','Barby Witherspoon','bwitherspoong@barnesandnoble.com','908-872-6376','44859 Pennsylvania Parkway',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(18,'Aimbo','Conan Tzarkov','ctzarkovh@ftc.gov','675-455-2222','8 Annamark Hill',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(19,'Photobug','Elora Simonassi','esimonassii@salon.com','329-696-2294','2038 Monterey Avenue',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(20,'Twimbo','Addia Carnall','acarnallj@sogou.com','302-508-3446','2679 Di Loreto Alley',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(21,'Tambee','Nanine Pallent','npallentk@ox.ac.uk','673-764-6971','98 Canary Hill',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(22,'Kamba','Paco Abdee','pabdeel@blogger.com','603-717-6862','84 Southridge Pass',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(23,'Tagcat','Taffy Addekin','taddekinm@bbb.org','254-848-5434','09868 Gerald Point',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(24,'Centizu','Levon Keller','lkellern@w3.org','642-210-7759','1717 Vidon Plaza',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(25,'Bubblemix','Gweneth Staniforth','gstanifortho@archive.org','857-465-5011','198 Novick Trail',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(26,'Rooxo','Cyb McCraw','cmccrawp@behance.net','864-137-9649','68431 Dixon Alley',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(27,'Jetpulse','Amandy Musgrove','amusgroveq@webs.com','903-962-2962','8 Upham Avenue',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(28,'Edgeify','Orv Poli','opolir@illinois.edu','797-878-8025','47592 Scott Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(29,'Mynte','Norean Duly','ndulys@hibu.com','312-986-5488','784 Blaine Lane',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(30,'Topiclounge','Valma Chatten','vchattent@slashdot.org','558-343-9322','40740 Grayhawk Point',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(31,'Topiczoom','Chaim Dunniom','cdunniomu@mediafire.com','981-505-9626','02272 Raven Street',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(32,'Yacero','Grange Tinton','gtintonv@quantcast.com','163-752-0363','84293 Warbler Hill',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(33,'Ailane','Franny Godfery','fgodferyw@e-recht24.de','398-548-7737','712 Shoshone Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(34,'Kayveo','Alane Robertacci','arobertaccix@nps.gov','502-324-2248','718 Elmside Point',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(35,'Realcube','Barnaby Menel','bmenely@rakuten.co.jp','470-406-2420','3724 Arrowood Point',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(36,'Rooxo','Enrichetta Dyers','edyersz@usgs.gov','129-149-7310','740 Nobel Junction',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(37,'Einti','Alanna Maycock','amaycock10@answers.com','529-212-6664','04451 Park Meadow Park',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(38,'Edgepulse','Giulietta Doulton','gdoulton11@twitpic.com','429-880-9325','84 Oak Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(39,'Voolith','Dolph Gruby','dgruby12@miitbeian.gov.cn','303-138-9917','0 Corben Street',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(40,'Thoughtworks','Lucie Freestone','lfreestone13@si.edu','431-767-1703','76628 Talmadge Avenue',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(41,'Divape','Ransell Bricham','rbricham14@paginegialle.it','805-297-5156','7 South Avenue',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(42,'Dablist','Rita Symson','rsymson15@mapquest.com','619-607-5503','9 Continental Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(43,'Flipstorm','Joellen Kyle','jkyle16@de.vu','593-477-4720','7 Longview Hill',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(44,'Tazz','Caddric Nobes','cnobes17@icio.us','999-252-6725','4277 Randy Trail',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(45,'Gabcube','Creight Guidera','cguidera18@google.com','791-849-4174','68 Rusk Road',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(46,'Blognation','Retha Ketton','rketton19@i2i.jp','772-345-3239','02979 Victoria Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(47,'Buzzdog','Naomi Incogna','nincogna1a@360.cn','874-477-4357','0 Fuller Hill',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(48,'Skippad','Broderick Flannigan','bflannigan1b@macromedia.com','907-213-3067','582 Loomis Terrace',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(49,'Trilia','Roberta Mallall','rmallall1c@nhs.uk','699-639-3816','86548 Brown Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(50,'Yoveo','Jada Malham','jmalham1d@google.pl','765-918-2498','8 Bartelt Junction',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(51,'Twitterbridge','Fidela Gascone','fgascone1e@yale.edu','434-919-7166','6 Prairie Rose Street',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(52,'Zooveo','Babbie Impy','bimpy1f@furl.net','536-332-7950','578 Laurel Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(53,'Linklinks','Aidan McCreadie','amccreadie1g@va.gov','216-636-2362','47 Sundown Lane',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(54,'Oyoyo','Melessa Tague','mtague1h@archive.org','879-762-3671','95 Montana Junction',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(55,'Fiveclub','Garrot Louth','glouth1i@army.mil','822-931-4540','3 Mariners Cove Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(56,'JumpXS','Lotte Vinnick','lvinnick1j@kickstarter.com','854-249-6169','39682 Porter Point',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(57,'Jatri','Cherye Dowry','cdowry1k@dion.ne.jp','219-541-2756','28029 Northport Parkway',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(58,'Yodo','Lib Emmett','lemmett1l@alibaba.com','749-819-5967','2 Northridge Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(59,'Oozz','Salomo Ruskin','sruskin1m@google.pl','415-258-1870','325 Dryden Circle',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(60,'Photolist','Randie Goodered','rgoodered1n@cnn.com','542-778-6416','3179 Mallory Plaza',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(61,'Shuffledrive','Natty Lerohan','nlerohan1o@irs.gov','952-275-4160','490 Mitchell Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(62,'Cogidoo','Matt Vause','mvause1p@abc.net.au','626-724-3325','16468 Heffernan Hill',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(63,'Flipopia','Ivor Destouche','idestouche1q@spotify.com','332-676-1985','432 Gateway Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(64,'Zoomdog','Rees Ganiford','rganiford1r@discovery.com','626-805-4472','5910 Jana Place',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(65,'Avamba','Nels Amor','namor1s@webnode.com','583-382-6420','97278 Northwestern Court',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(66,'Plajo','Giustino Shay','gshay1t@miibeian.gov.cn','433-634-4103','51 Northland Avenue',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(67,'Muxo','Ruperta Caldecourt','rcaldecourt1u@mozilla.org','480-311-2036','76 Melody Court',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(68,'Ooba','Mari Pietron','mpietron1v@rakuten.co.jp','525-786-5218','706 Reindahl Circle',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(69,'Yambee','Carmelita Stonestreet','cstonestreet1w@virginia.edu','860-974-8897','2812 Orin Street',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(70,'Jayo','Johnnie Headingham','jheadingham1x@google.cn','462-393-6963','4177 Gerald Park',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(71,'Kwilith','Petra Millett','pmillett1y@technorati.com','832-320-8861','914 Hagan Pass',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(72,'Realmix','Caroline Culpen','cculpen1z@addthis.com','504-212-6399','11 Aberg Alley',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(73,'Babbleblab','Joe MacHostie','jmachostie20@independent.co.uk','508-726-1645','09 Arizona Circle',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(74,'Skyndu','Randee Noton','rnoton21@economist.com','625-171-7557','0358 Independence Terrace',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(75,'Buzzshare','Celeste Steuart','csteuart22@theatlantic.com','533-613-5437','76381 Cardinal Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(76,'Demimbu','Natassia Crotty','ncrotty23@home.pl','419-476-9313','353 Ohio Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(77,'Kimia','Dugald Bleby','dbleby24@utexas.edu','369-790-5073','06577 Southridge Drive',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(78,'Wikizz','Garrik Salzen','gsalzen25@photobucket.com','120-881-7209','8 Brentwood Crossing',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(79,'Plambee','Friederike Bew','fbew26@go.com','445-723-2557','2 Prentice Hill',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(80,'Skinder','Harmonia Barks','hbarks27@printfriendly.com','171-185-2766','3382 Dottie Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(81,'Abata','Windy Gratrix','wgratrix28@jiathis.com','904-659-1179','2575 Division Drive',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(82,'Flipbug','Isador Connerry','iconnerry29@parallels.com','542-640-3398','90282 Lillian Avenue',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(83,'Layo','Marleen Landsberg','mlandsberg2a@google.co.jp','628-413-7681','3 Dunning Drive',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(84,'Aibox','Lana Knock','lknock2b@blinklist.com','946-984-3844','42010 Eastlawn Trail',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(85,'Kimia','Phillipe Klewi','pklewi2c@weebly.com','404-466-1201','471 Sherman Court',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(86,'Kwimbee','Thomasin Kinkaid','tkinkaid2d@epa.gov','513-777-4063','7 Reindahl Court',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(87,'Quinu','Nicolette Wrathmell','nwrathmell2e@flickr.com','167-863-1392','37 Vahlen Trail',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(88,'Ooba','Tamarah Stelfax','tstelfax2f@tinyurl.com','574-739-8312','86814 Mayer Road',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(89,'Skiptube','Kinny Clarkson','kclarkson2g@nydailynews.com','939-231-3107','65194 Mcguire Drive',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(90,'Yabox','Cornie Goodsal','cgoodsal2h@yolasite.com','731-631-2135','900 Lukken Terrace',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(91,'Einti','Ange Quillinane','aquillinane2i@gmpg.org','984-187-9747','803 Bluejay Lane',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(92,'Bubbletube','Fannie Tremmel','ftremmel2j@imageshack.us','541-483-4758','13399 Sutteridge Lane',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(93,'Flipstorm','Jud Johncey','jjohncey2k@facebook.com','830-459-5696','23 Brown Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(94,'Browsebug','Erskine Boothman','eboothman2l@chron.com','783-175-1133','2 4th Center',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(95,'Quaxo','Valentijn Gheeraert','vgheeraert2m@icq.com','359-608-7545','51684 Scott Parkway',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(96,'Realmix','Jasen Daborn','jdaborn2n@moonfruit.com','736-410-3591','4589 Golf View Parkway',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(97,'Oozz','Dulci Connaughton','dconnaughton2o@wordpress.com','484-998-1984','6026 Carberry Trail',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(98,'Photofeed','Georg Vinten','gvinten2p@tamu.edu','260-968-9805','25612 Forest Place',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(99,'Meembee','Raphaela Eadon','readon2q@mtv.com','789-549-0423','0780 Transport Way',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL),(100,'Trunyx','Renell Huriche','rhuriche2r@oracle.com','768-588-4335','1 Hansons Junction',NULL,1,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Joel Carlos','killerbytes','joelcarlos02@gmail.com','$2b$08$Igjh/1J9ax7nf5IRw1jJgO4GGFyCOD40tUcKYIJZps3A0PgE3D09.',1,0,'2025-08-20 12:44:13','2025-08-20 12:44:13',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `varianttypes`
--

LOCK TABLES `varianttypes` WRITE;
/*!40000 ALTER TABLE `varianttypes` DISABLE KEYS */;
INSERT INTO `varianttypes` VALUES (1,'Type',1,NULL,'2025-08-20 12:45:04','2025-08-20 12:45:04'),(2,'Shovel Type',NULL,1,'2025-08-20 12:57:45','2025-08-20 12:57:45'),(3,'Type',6,NULL,'2025-08-20 12:58:03','2025-08-20 12:58:03'),(4,'Wattage',7,NULL,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(5,'Wattage',8,NULL,'2025-08-20 13:02:26','2025-08-20 13:02:26'),(6,'Type 3',9,NULL,'2025-08-20 13:09:27','2025-08-20 13:13:41'),(7,'Type 2',9,NULL,'2025-08-20 13:09:48','2025-08-20 13:09:48'),(8,'AMP',10,NULL,'2025-08-20 13:19:10','2025-08-20 13:19:10'),(9,'CIRCUIT BREAKER AMP',NULL,1,'2025-08-20 13:19:57','2025-08-20 13:19:57'),(10,'TYPE',10,NULL,'2025-08-20 13:22:26','2025-08-20 13:22:26');
/*!40000 ALTER TABLE `varianttypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `variantvalues`
--

LOCK TABLES `variantvalues` WRITE;
/*!40000 ALTER TABLE `variantvalues` DISABLE KEYS */;
INSERT INTO `variantvalues` VALUES (1,'Spade',1,'2025-08-20 12:45:04','2025-08-20 12:45:04'),(2,'Square',1,'2025-08-20 12:45:04','2025-08-20 12:45:04'),(3,'Square',2,'2025-08-20 12:57:45','2025-08-20 12:57:45'),(4,'Spade',2,'2025-08-20 12:57:45','2025-08-20 12:57:45'),(5,'Spade',3,'2025-08-20 12:58:03','2025-08-20 12:58:03'),(6,'Square',3,'2025-08-20 12:58:03','2025-08-20 12:58:03'),(7,'3w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(8,'5w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(9,'7w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(10,'9w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(11,'11w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(12,'13w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(13,'15w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(14,'17w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(15,'19w',4,'2025-08-20 12:59:37','2025-08-20 12:59:37'),(16,'9w',5,'2025-08-20 13:02:26','2025-08-20 13:02:26'),(17,'18w',5,'2025-08-20 13:02:26','2025-08-20 13:02:26'),(18,'2x2',6,'2025-08-20 13:09:27','2025-08-20 13:09:27'),(19,'3x3',6,'2025-08-20 13:09:27','2025-08-20 13:09:27'),(20,'4x4',6,'2025-08-20 13:09:27','2025-08-20 13:09:27'),(21,'2B',7,'2025-08-20 13:09:48','2025-08-20 13:09:48'),(22,'4B',7,'2025-08-20 13:09:48','2025-08-20 13:09:48'),(23,'6B',7,'2025-08-20 13:09:48','2025-08-20 13:09:48'),(24,'15A - 20A - 30A',8,'2025-08-20 13:19:10','2025-08-20 13:19:10'),(25,'40A - 50A - 60A',8,'2025-08-20 13:19:10','2025-08-20 13:19:10'),(26,'70A',8,'2025-08-20 13:19:10','2025-08-20 13:19:10'),(27,'100A',8,'2025-08-20 13:19:10','2025-08-20 13:19:10'),(28,'15A - 20A - 30A',9,'2025-08-20 13:19:57','2025-08-20 13:19:57'),(29,'40A - 50A - 60A',9,'2025-08-20 13:19:57','2025-08-20 13:19:57'),(30,'70A',9,'2025-08-20 13:19:57','2025-08-20 13:19:57'),(31,'100A',9,'2025-08-20 13:19:57','2025-08-20 13:19:57'),(32,'2P Plug-in',10,'2025-08-20 13:22:26','2025-08-20 13:22:26'),(33,'3P Plug-in',10,'2025-08-20 13:22:26','2025-08-20 13:22:26'),(34,'2P Bolt-on',10,'2025-08-20 13:22:26','2025-08-20 13:22:26'),(35,'3P Bolt-on',10,'2025-08-20 13:22:26','2025-08-20 13:22:26');
/*!40000 ALTER TABLE `variantvalues` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-21  8:19:54
