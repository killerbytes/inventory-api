--
-- PostgreSQL database dump
--

\restrict AuEZYJndmIAJknLdfgksHAtng2jOZhe5lxnBXVF7JFZMl8dZSF5ZJoFja91Qvt0

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: Categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Categories" (id, name, description, "order", "deletedAt", "parentId") FROM stdin;
1	Building Materials		0	\N	\N
2	Paints and Accessories		1	\N	\N
3	Hardware		2	\N	\N
4	Plumbing		3	\N	\N
5	Tools		4	\N	\N
6	Electrical		5	\N	\N
7	Adhesives and Sealants		6	\N	\N
8	Grease and Lubricants		7	\N	\N
\.


--
-- Data for Name: Products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Products" (id, name, description, "categoryId", sku, "createdAt", "updatedAt", "deletedAt", "baseUnit") FROM stdin;
1	Shovel	\N	5	05|SHO	2025-08-26 14:08:26.134+08	2025-08-26 14:08:26.134+08	\N	PCS
2	Siltite Silicon Sealant	\N	7	07|SILTIT_SIL	2025-08-26 14:16:29.869+08	2025-08-26 14:16:29.869+08	\N	PCS
3	WD-40	\N	8	08|WD40	2025-08-26 14:23:04.347+08	2025-08-26 14:23:04.347+08	\N	PCS
5	Level Hose Heavy Duty	\N	3	03|LEVEL_HOSE	2025-08-26 15:07:34.894+08	2025-08-26 15:09:52.36+08	\N	RLS
7	Metal Flex. Conduit	\N	3	03|METAL_FLEX	2025-08-26 15:13:51.192+08	2025-08-26 15:13:51.192+08	\N	RLS
8	Mica Tube	\N	3	03|MICA_TUBE	2025-08-26 15:15:21.347+08	2025-08-26 15:15:21.347+08	\N	RLS
6	[Euroflex] Flexible	\N	3	03|EUROFL_FLE	2025-08-26 15:11:23.011+08	2025-08-26 15:23:18.146+08	\N	RLS
10	Ever S/Switch	\N	6	06|EVER_SSWIT	2025-08-26 15:24:25.741+08	2025-08-26 15:24:25.741+08	\N	PCS
11	Plastic straw	\N	3	01|PLASTI_STR	2025-08-26 15:33:17.698+08	2025-08-26 16:05:18.449+08	\N	RLS
9	[Poly] PEHose	\N	3	03|POLY_PEHOS	2025-08-26 15:17:41.61+08	2025-08-26 16:17:52.849+08	\N	RLS
4	Superflex Chemical Hose	\n	1	03|SUPERF_CHE	2025-08-26 14:42:04.383+08	2025-08-26 16:23:30.218+08	\N	RLS
12	[PN20] PP-R Pipe	\N	4	04|PN20_PPR_P	2025-08-26 18:31:58.456+08	2025-08-26 18:31:58.456+08	\N	PCS
13	[Godex] PP-R Coupling	\N	4	04|GODEX_PPR_	2025-08-26 18:34:44.018+08	2025-08-26 18:34:44.018+08	\N	PCS
14	[Godex] PP-R Elbow	\n	4	04|GODEX_PPR_	2025-08-26 18:36:22.333+08	2025-08-26 18:36:22.333+08	\N	PCS
15	[Godex] PP-R End Cap	\N	4	04|GODEX_PPR_	2025-08-26 19:33:27.452+08	2025-08-26 19:33:27.452+08	\N	PCS
\.


--
-- Data for Name: ProductCombinations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductCombinations" (id, "productId", name, sku, price, "reorderLevel", "createdAt", "updatedAt", "deletedAt", unit, "conversionFactor") FROM stdin;
1	1	Shovel - Spade	05|SHOVEL|PCS|SPA	75.00	10	2025-08-26 14:08:52.046+08	2025-08-26 14:11:03.316+08	\N	PCS	1
2	1	Shovel - Square	05|SHOVEL|PCS|SQU	75.00	10	2025-08-26 14:08:52.057+08	2025-08-26 14:11:03.333+08	\N	PCS	1
6	3	WD-40 - (12.9oz) - 302ml	08|WD40|PCS|129__302	481.00	10	2025-08-26 14:25:16.956+08	2025-08-26 14:25:16.956+08	\N	PCS	1
7	3	WD-40 - (3.0oz) - 100ml	08|WD40|PCS|30O__100	279.00	10	2025-08-26 14:25:16.962+08	2025-08-26 14:25:16.962+08	\N	PCS	1
8	3	WD-40 - (6.5oz) - 191ml	08|WD40|PCS|65O__191	304.00	10	2025-08-26 14:25:16.967+08	2025-08-26 14:25:16.967+08	\N	PCS	1
9	4	Superflex Chemical Hose - 	03|SUPERF_CHE|RLS	3900.00	10	2025-08-26 14:42:50.443+08	2025-08-26 14:42:50.443+08	\N	RLS	1
10	5	Level Hose Heavy Duty - Green | 3/8x500ft	03|LEVEL_HOSE|RLS|GRE|38X	1820.00	10	2025-08-26 15:09:40.581+08	2025-08-26 15:09:40.581+08	\N	RLS	1
11	5	Level Hose Heavy Duty - Green | 5/16x500ft	03|LEVEL_HOSE|RLS|GRE|516	1470.00	10	2025-08-26 15:09:40.608+08	2025-08-26 15:09:40.608+08	\N	RLS	1
14	7	Metal Flex. Conduit - 30a | 1/2	03|METAL_FLEX|RLS|30A|12	475.00	10	2025-08-26 15:15:02.284+08	2025-08-26 15:15:02.284+08	\N	RLS	1
15	8	Mica Tube - 60a | 3/8	03|MICA_TUBE|RLS|60A|38	995.00	10	2025-08-26 15:16:19.183+08	2025-08-26 15:16:19.183+08	\N	RLS	1
12	6	[Euroflex] Flexible - 100m | 1/2	03|EUROFL_FLE|RLS|100|12	469.00	10	2025-08-26 15:12:47.649+08	2025-08-26 15:23:42.185+08	\N	RLS	1
13	6	[Euroflex] Flexible - 50m | 1/2	03|EUROFL_FLE|RLS|50M|12	234.00	10	2025-08-26 15:12:47.658+08	2025-08-26 15:23:42.187+08	\N	RLS	1
20	10	Ever S/Switch - 30A | 2P | ST	06|EVER_SSWIT|PCS|30A|2P|ST	570.00	10	2025-08-26 15:26:17.332+08	2025-08-26 15:26:17.332+08	\N	PCS	1
21	10	Ever S/Switch - 60A | 2P | ST	06|EVER_SSWIT|PCS|60A|2P|ST	830.00	10	2025-08-26 15:26:17.343+08	2025-08-26 15:26:17.343+08	\N	PCS	1
22	11	Plastic straw - 1kilo | Regular	01|PLASTI_STR|RLS|1KI|REG	65.00	10	2025-08-26 15:49:11.196+08	2025-08-26 15:49:11.196+08	\N	RLS	1
23	11	Plastic straw - 1kilo | HD	01|PLASTI_STR|RLS|1KI|HD	88.00	10	2025-08-26 15:49:11.21+08	2025-08-26 15:49:11.21+08	\N	RLS	1
17	9	[Poly] PEHose - Blue | 1/2 | SDR-11 | 300	03|POLY_PEHOS|RLS|BLU|12|SDR|300	5355.00	10	2025-08-26 15:22:41.52+08	2025-08-26 16:18:04.688+08	\N	RLS	1
16	9	[Poly] PEHose - Blue | 1/2 | SDR-11 | 100	03|POLY_PEHOS|RLS|BLU|12|SDR|100	1785.00	10	2025-08-26 15:22:41.509+08	2025-08-26 16:18:04.694+08	\N	RLS	1
18	9	[Poly] PEHose - Blue | 3/4 | SDR-11 | 150	03|POLY_PEHOS|RLS|BLU|34|SDR|150	3700.00	10	2025-08-26 15:22:41.541+08	2025-08-26 16:18:04.697+08	\N	RLS	1
19	9	[Poly] PEHose - Blue | 1 | SDR-11 | 100	03|POLY_PEHOS|RLS|BLU|1|SDR|100	4040.00	10	2025-08-26 15:22:41.551+08	2025-08-26 16:18:04.701+08	\N	RLS	1
3	2	Siltite Silicon Sealant - Black	07|SILTIT_SIL|PCS|BLA	116.00	10	2025-08-26 14:17:31.644+08	2025-08-26 18:30:34.711+08	\N	PCS	1
4	2	Siltite Silicon Sealant - Clear	07|SILTIT_SIL|PCS|CLE	116.00	10	2025-08-26 14:17:31.655+08	2025-08-26 18:30:34.715+08	\N	PCS	1
5	2	Siltite Silicon Sealant - White	07|SILTIT_SIL|PCS|WHI	116.00	10	2025-08-26 14:17:31.66+08	2025-08-26 18:30:34.718+08	\N	PCS	1
24	2	Siltite Silicon Sealant - Brown/Bronze	07|SILTIT_SIL|PCS|BRO	116.00	10	2025-08-26 18:30:34.72+08	2025-08-26 18:30:34.72+08	\N	PCS	1
25	12	[PN20] PP-R Pipe - 3/4 | 3.5mm | 4mts	04|PN20_PPR_P|PCS|34|35M|4MT	538.00	10	2025-08-26 18:33:49.968+08	2025-08-26 18:33:49.968+08	\N	PCS	1
26	12	[PN20] PP-R Pipe - 1/2 | 2.88mm | 4mts	04|PN20_PPR_P|PCS|12|288|4MT	348.00	10	2025-08-26 18:33:49.976+08	2025-08-26 18:33:49.976+08	\N	PCS	1
27	13	[Godex] PP-R Coupling - 1/2	04|GODEX_PPR_|PCS|12	12.00	10	2025-08-26 18:35:56.587+08	2025-08-26 18:35:56.587+08	\N	PCS	1
28	13	[Godex] PP-R Coupling - 3/4	04|GODEX_PPR_|PCS|34	16.00	10	2025-08-26 18:35:56.595+08	2025-08-26 18:35:56.595+08	\N	PCS	1
29	14	[Godex] PP-R Elbow - 45 | 1/2	04|GODEX_PPR_|PCS|45|12	14.00	10	2025-08-26 18:38:45.955+08	2025-08-26 18:39:08.283+08	\N	PCS	1
30	14	[Godex] PP-R Elbow - 90 | 1/2	04|GODEX_PPR_|PCS|90|12	16.00	10	2025-08-26 18:38:45.963+08	2025-08-26 18:39:08.285+08	\N	PCS	1
31	14	[Godex] PP-R Elbow - 90 | 1	04|GODEX_PPR_|PCS|90|1	40.00	10	2025-08-26 18:38:45.966+08	2025-08-26 18:39:08.287+08	\N	PCS	1
32	14	[Godex] PP-R Elbow - 90 | 3/4	04|GODEX_PPR_|PCS|90|34	26.00	10	2025-08-26 18:39:08.289+08	2025-08-26 18:39:08.289+08	\N	PCS	1
47	15	[Godex] PP-R End Cap - 1	04|GODEX_END_|PCS|1	21.00	10	2025-08-26 19:40:03.181+08	2025-08-26 19:40:03.181+08	2025-08-26 19:40:51.84+08	PCS	1
48	15	[Godex] PP-R End Cap - 1/2	04|GODEX_END_|PCS|12	9.00	10	2025-08-26 19:40:03.195+08	2025-08-26 19:40:03.195+08	2025-08-26 19:40:51.84+08	PCS	1
49	15	[Godex] PP-R End Cap - 3/4	04|GODEX_END_|PCS|34	19.00	10	2025-08-26 19:40:03.202+08	2025-08-26 19:40:03.202+08	2025-08-26 19:40:51.84+08	PCS	1
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Users" (id, name, username, email, password, "isActive", "isAdmin", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Admin	admin	admin@email.com	$2b$08$BwRhRpz6W97nfUICpyWP2OWBvOlaTYgfy/xtuR.In3BbBii.T9WRy	t	f	2025-08-26 14:02:41.546+08	2025-08-26 14:02:41.546+08	\N
2	Joel Carlos	killerbytes	joelcarlos02@gmail.com	$2b$08$IMqjhjcqkTdl4vh/8zF1reYBIdCyJ0wUsejvLBk4yZJqhWPBuf3yS	t	f	2025-08-26 14:02:41.558+08	2025-08-26 14:02:41.558+08	\N
\.


--
-- Data for Name: BreakPacks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."BreakPacks" (id, "fromCombinationId", "toCombinationId", quantity, "conversionFactor", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: VariantTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VariantTypes" (id, name, "productId", "isTemplate", "createdAt", "updatedAt") FROM stdin;
1	Type	1	\N	2025-08-26 14:08:36.24+08	2025-08-26 14:08:36.24+08
2	Color	2	\N	2025-08-26 14:16:58.621+08	2025-08-26 14:16:58.621+08
3	Size	3	\N	2025-08-26 14:24:40.561+08	2025-08-26 14:24:40.561+08
4	Size	5	\N	2025-08-26 15:08:19.283+08	2025-08-26 15:08:19.283+08
5	Color	5	\N	2025-08-26 15:08:45.793+08	2025-08-26 15:08:45.793+08
6	Size	6	\N	2025-08-26 15:11:55.87+08	2025-08-26 15:11:55.87+08
7	Length	6	\N	2025-08-26 15:12:15.602+08	2025-08-26 15:12:15.602+08
8	Size	7	\N	2025-08-26 15:14:14.761+08	2025-08-26 15:14:14.761+08
9	Amp	7	\N	2025-08-26 15:14:41.176+08	2025-08-26 15:14:41.176+08
10	Size	8	\N	2025-08-26 15:15:36.855+08	2025-08-26 15:15:36.855+08
11	Amp	8	\N	2025-08-26 15:16:02.299+08	2025-08-26 15:16:02.299+08
12	Size	9	\N	2025-08-26 15:18:12.466+08	2025-08-26 15:18:12.466+08
13	Type	9	\N	2025-08-26 15:18:51.473+08	2025-08-26 15:18:51.473+08
14	Color	9	\N	2025-08-26 15:21:22.715+08	2025-08-26 15:21:22.715+08
15	Amp	10	\N	2025-08-26 15:24:57.846+08	2025-08-26 15:24:57.846+08
16	Type	10	\N	2025-08-26 15:25:09.745+08	2025-08-26 15:25:09.745+08
17	Type 2	10	\N	2025-08-26 15:25:30.688+08	2025-08-26 15:25:30.688+08
18	Size	11	\N	2025-08-26 15:33:46.049+08	2025-08-26 15:33:46.049+08
19	Type	11	\N	2025-08-26 15:48:40.373+08	2025-08-26 15:48:40.373+08
20	Thickness	9	\N	2025-08-26 16:17:33.441+08	2025-08-26 16:17:33.441+08
21	Size1	12	\N	2025-08-26 18:32:37.517+08	2025-08-26 18:32:37.517+08
22	Size2	12	\N	2025-08-26 18:33:04.853+08	2025-08-26 18:33:04.853+08
23	Size3	12	\N	2025-08-26 18:33:15.232+08	2025-08-26 18:33:15.232+08
24	Size	13	\N	2025-08-26 18:35:13.179+08	2025-08-26 18:35:13.179+08
25	PP-R Size	\N	t	2025-08-26 18:35:23.128+08	2025-08-26 18:35:23.128+08
26	Angle	14	\N	2025-08-26 18:36:51.771+08	2025-08-26 18:36:51.771+08
27	Size	14	\N	2025-08-26 18:37:09.833+08	2025-08-26 18:37:09.833+08
28	PP-R Size	15	\N	2025-08-26 19:33:44.049+08	2025-08-26 19:33:44.049+08
29	PP-R Size	\N	t	2025-08-26 19:34:06.804+08	2025-08-26 19:34:06.804+08
\.


--
-- Data for Name: VariantValues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."VariantValues" (id, value, "variantTypeId", "createdAt", "updatedAt") FROM stdin;
1	Spade	1	2025-08-26 14:08:36.242+08	2025-08-26 14:08:36.242+08
2	Square	1	2025-08-26 14:08:36.243+08	2025-08-26 14:08:36.243+08
3	Black	2	2025-08-26 14:16:58.624+08	2025-08-26 14:16:58.624+08
4	Clear	2	2025-08-26 14:16:58.625+08	2025-08-26 14:16:58.625+08
5	White	2	2025-08-26 14:16:58.626+08	2025-08-26 14:16:58.626+08
6	(12.9oz) - 302ml	3	2025-08-26 14:24:40.565+08	2025-08-26 14:24:40.565+08
7	(3.0oz) - 100ml	3	2025-08-26 14:24:40.567+08	2025-08-26 14:24:40.567+08
8	(6.5oz) - 191ml	3	2025-08-26 14:24:40.568+08	2025-08-26 14:24:40.568+08
9	3/8x500ft	4	2025-08-26 15:08:19.287+08	2025-08-26 15:08:19.287+08
10	5/16x500ft	4	2025-08-26 15:08:19.291+08	2025-08-26 15:08:19.291+08
11	Green	5	2025-08-26 15:08:45.795+08	2025-08-26 15:08:45.795+08
12	1/2	6	2025-08-26 15:11:55.874+08	2025-08-26 15:11:55.874+08
13	100m	7	2025-08-26 15:12:15.605+08	2025-08-26 15:12:15.605+08
14	50m	7	2025-08-26 15:12:15.607+08	2025-08-26 15:12:15.607+08
15	1/2	8	2025-08-26 15:14:14.765+08	2025-08-26 15:14:14.765+08
16	30a	9	2025-08-26 15:14:41.18+08	2025-08-26 15:14:41.18+08
17	3/8	10	2025-08-26 15:15:36.859+08	2025-08-26 15:15:36.859+08
18	60a	11	2025-08-26 15:16:02.303+08	2025-08-26 15:16:02.303+08
19	1/2	12	2025-08-26 15:18:12.471+08	2025-08-26 15:18:12.471+08
20	3/4	12	2025-08-26 15:18:12.472+08	2025-08-26 15:18:12.472+08
21	1	12	2025-08-26 15:18:12.473+08	2025-08-26 15:18:12.473+08
22	100	13	2025-08-26 15:18:51.477+08	2025-08-26 15:18:51.477+08
23	150	13	2025-08-26 15:18:51.479+08	2025-08-26 15:18:51.479+08
24	300	13	2025-08-26 15:18:51.48+08	2025-08-26 15:18:51.48+08
25	Blue	14	2025-08-26 15:21:22.721+08	2025-08-26 15:21:22.721+08
26	30A	15	2025-08-26 15:24:57.849+08	2025-08-26 15:24:57.849+08
27	60A	15	2025-08-26 15:24:57.852+08	2025-08-26 15:24:57.852+08
28	2P	16	2025-08-26 15:25:09.75+08	2025-08-26 15:25:09.75+08
29	ST	17	2025-08-26 15:25:30.692+08	2025-08-26 15:25:30.692+08
30	1kilo	18	2025-08-26 15:33:46.052+08	2025-08-26 15:33:46.052+08
31	Regular	19	2025-08-26 15:48:40.379+08	2025-08-26 15:48:40.379+08
32	HD	19	2025-08-26 15:48:40.382+08	2025-08-26 15:48:40.382+08
33	SDR-11	20	2025-08-26 16:17:33.454+08	2025-08-26 16:17:33.454+08
34	Brown/Bronze	2	2025-08-26 18:30:20.517+08	2025-08-26 18:30:20.517+08
35	3/4	21	2025-08-26 18:32:37.52+08	2025-08-26 18:32:37.52+08
36	1/2	21	2025-08-26 18:32:37.521+08	2025-08-26 18:32:37.521+08
37	3.5mm	22	2025-08-26 18:33:04.855+08	2025-08-26 18:33:04.855+08
38	2.88mm	22	2025-08-26 18:33:04.857+08	2025-08-26 18:33:04.857+08
39	4mts	23	2025-08-26 18:33:15.234+08	2025-08-26 18:33:15.234+08
40	1/2	24	2025-08-26 18:35:13.181+08	2025-08-26 18:35:13.181+08
41	3/4	24	2025-08-26 18:35:13.182+08	2025-08-26 18:35:13.182+08
42	1/2	25	2025-08-26 18:35:23.129+08	2025-08-26 18:35:23.129+08
43	3/4	25	2025-08-26 18:35:23.13+08	2025-08-26 18:35:23.13+08
44	45	26	2025-08-26 18:36:51.774+08	2025-08-26 18:36:51.774+08
45	90	26	2025-08-26 18:36:51.775+08	2025-08-26 18:36:51.775+08
46	1	27	2025-08-26 18:37:09.836+08	2025-08-26 18:37:09.836+08
47	1/2	27	2025-08-26 18:37:09.837+08	2025-08-26 18:37:09.837+08
48	3/4	27	2025-08-26 18:38:58.412+08	2025-08-26 18:38:58.412+08
49	1/2	28	2025-08-26 19:33:44.05+08	2025-08-26 19:33:44.05+08
50	3/4	28	2025-08-26 19:33:44.051+08	2025-08-26 19:33:44.051+08
51	1	28	2025-08-26 19:33:44.051+08	2025-08-26 19:33:44.051+08
52	1/2	29	2025-08-26 19:34:06.805+08	2025-08-26 19:34:06.805+08
53	3/4	29	2025-08-26 19:34:06.806+08	2025-08-26 19:34:06.806+08
54	1	29	2025-08-26 19:34:06.807+08	2025-08-26 19:34:06.807+08
\.


--
-- Data for Name: CombinationValues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CombinationValues" ("combinationId", "variantValueId", "createdAt", "updatedAt") FROM stdin;
1	1	2025-08-26 14:08:52.048+08	2025-08-26 14:08:52.048+08
2	2	2025-08-26 14:08:52.059+08	2025-08-26 14:08:52.059+08
3	3	2025-08-26 14:17:31.646+08	2025-08-26 14:17:31.646+08
4	4	2025-08-26 14:17:31.657+08	2025-08-26 14:17:31.657+08
5	5	2025-08-26 14:17:31.663+08	2025-08-26 14:17:31.663+08
6	6	2025-08-26 14:25:16.957+08	2025-08-26 14:25:16.957+08
7	7	2025-08-26 14:25:16.964+08	2025-08-26 14:25:16.964+08
8	8	2025-08-26 14:25:16.97+08	2025-08-26 14:25:16.97+08
10	11	2025-08-26 15:09:40.585+08	2025-08-26 15:09:40.585+08
10	9	2025-08-26 15:09:40.585+08	2025-08-26 15:09:40.585+08
11	11	2025-08-26 15:09:40.609+08	2025-08-26 15:09:40.609+08
11	10	2025-08-26 15:09:40.609+08	2025-08-26 15:09:40.609+08
12	13	2025-08-26 15:12:47.651+08	2025-08-26 15:12:47.651+08
12	12	2025-08-26 15:12:47.651+08	2025-08-26 15:12:47.651+08
13	14	2025-08-26 15:12:47.661+08	2025-08-26 15:12:47.661+08
13	12	2025-08-26 15:12:47.661+08	2025-08-26 15:12:47.661+08
14	16	2025-08-26 15:15:02.286+08	2025-08-26 15:15:02.286+08
14	15	2025-08-26 15:15:02.286+08	2025-08-26 15:15:02.286+08
15	18	2025-08-26 15:16:19.185+08	2025-08-26 15:16:19.185+08
15	17	2025-08-26 15:16:19.185+08	2025-08-26 15:16:19.185+08
16	25	2025-08-26 15:22:41.51+08	2025-08-26 15:22:41.51+08
16	19	2025-08-26 15:22:41.51+08	2025-08-26 15:22:41.51+08
16	22	2025-08-26 15:22:41.51+08	2025-08-26 15:22:41.51+08
17	25	2025-08-26 15:22:41.521+08	2025-08-26 15:22:41.521+08
17	19	2025-08-26 15:22:41.521+08	2025-08-26 15:22:41.521+08
17	24	2025-08-26 15:22:41.521+08	2025-08-26 15:22:41.521+08
18	25	2025-08-26 15:22:41.546+08	2025-08-26 15:22:41.546+08
18	20	2025-08-26 15:22:41.546+08	2025-08-26 15:22:41.546+08
18	23	2025-08-26 15:22:41.546+08	2025-08-26 15:22:41.546+08
19	25	2025-08-26 15:22:41.552+08	2025-08-26 15:22:41.552+08
19	21	2025-08-26 15:22:41.552+08	2025-08-26 15:22:41.552+08
19	22	2025-08-26 15:22:41.552+08	2025-08-26 15:22:41.552+08
20	26	2025-08-26 15:26:17.334+08	2025-08-26 15:26:17.334+08
20	28	2025-08-26 15:26:17.334+08	2025-08-26 15:26:17.334+08
20	29	2025-08-26 15:26:17.334+08	2025-08-26 15:26:17.334+08
21	27	2025-08-26 15:26:17.344+08	2025-08-26 15:26:17.344+08
21	28	2025-08-26 15:26:17.344+08	2025-08-26 15:26:17.344+08
21	29	2025-08-26 15:26:17.344+08	2025-08-26 15:26:17.344+08
22	30	2025-08-26 15:49:11.199+08	2025-08-26 15:49:11.199+08
22	31	2025-08-26 15:49:11.199+08	2025-08-26 15:49:11.199+08
23	30	2025-08-26 15:49:11.212+08	2025-08-26 15:49:11.212+08
23	32	2025-08-26 15:49:11.212+08	2025-08-26 15:49:11.212+08
17	33	2025-08-26 16:18:04.69+08	2025-08-26 16:18:04.69+08
16	33	2025-08-26 16:18:04.695+08	2025-08-26 16:18:04.695+08
18	33	2025-08-26 16:18:04.699+08	2025-08-26 16:18:04.699+08
19	33	2025-08-26 16:18:04.702+08	2025-08-26 16:18:04.702+08
24	34	2025-08-26 18:30:34.724+08	2025-08-26 18:30:34.724+08
25	35	2025-08-26 18:33:49.97+08	2025-08-26 18:33:49.97+08
25	37	2025-08-26 18:33:49.97+08	2025-08-26 18:33:49.97+08
25	39	2025-08-26 18:33:49.97+08	2025-08-26 18:33:49.97+08
26	36	2025-08-26 18:33:49.977+08	2025-08-26 18:33:49.977+08
26	38	2025-08-26 18:33:49.977+08	2025-08-26 18:33:49.977+08
26	39	2025-08-26 18:33:49.977+08	2025-08-26 18:33:49.977+08
27	40	2025-08-26 18:35:56.589+08	2025-08-26 18:35:56.589+08
28	41	2025-08-26 18:35:56.596+08	2025-08-26 18:35:56.596+08
29	44	2025-08-26 18:38:45.957+08	2025-08-26 18:38:45.957+08
29	47	2025-08-26 18:38:45.957+08	2025-08-26 18:38:45.957+08
30	45	2025-08-26 18:38:45.964+08	2025-08-26 18:38:45.964+08
30	47	2025-08-26 18:38:45.964+08	2025-08-26 18:38:45.964+08
31	45	2025-08-26 18:38:45.967+08	2025-08-26 18:38:45.967+08
31	46	2025-08-26 18:38:45.967+08	2025-08-26 18:38:45.967+08
32	45	2025-08-26 18:39:08.29+08	2025-08-26 18:39:08.29+08
32	48	2025-08-26 18:39:08.29+08	2025-08-26 18:39:08.29+08
47	51	2025-08-26 19:40:03.186+08	2025-08-26 19:40:03.186+08
48	49	2025-08-26 19:40:03.198+08	2025-08-26 19:40:03.198+08
49	50	2025-08-26 19:40:03.204+08	2025-08-26 19:40:03.204+08
\.


--
-- Data for Name: Customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customers" (id, name, email, phone, address, notes, "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	Default	\N	\N	Cabanatuan City	\N	t	2025-08-26 14:02:41.529+08	2025-08-26 14:02:41.529+08	\N
\.


--
-- Data for Name: Inventories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Inventories" (id, "combinationId", quantity, "createdAt", "updatedAt", "deletedAt") FROM stdin;
1	1	0	2025-08-26 14:08:52.051+08	2025-08-26 14:08:52.051+08	\N
2	2	0	2025-08-26 14:08:52.06+08	2025-08-26 14:08:52.06+08	\N
3	3	0	2025-08-26 14:17:31.649+08	2025-08-26 14:17:31.649+08	\N
4	4	0	2025-08-26 14:17:31.659+08	2025-08-26 14:17:31.659+08	\N
5	5	0	2025-08-26 14:17:31.665+08	2025-08-26 14:17:31.665+08	\N
6	6	0	2025-08-26 14:25:16.958+08	2025-08-26 14:25:16.958+08	\N
7	7	0	2025-08-26 14:25:16.965+08	2025-08-26 14:25:16.965+08	\N
8	8	0	2025-08-26 14:25:16.972+08	2025-08-26 14:25:16.972+08	\N
9	9	0	2025-08-26 14:42:50.446+08	2025-08-26 14:42:50.446+08	\N
10	10	0	2025-08-26 15:09:40.589+08	2025-08-26 15:09:40.589+08	\N
11	11	0	2025-08-26 15:09:40.612+08	2025-08-26 15:09:40.612+08	\N
12	12	0	2025-08-26 15:12:47.652+08	2025-08-26 15:12:47.652+08	\N
13	13	0	2025-08-26 15:12:47.662+08	2025-08-26 15:12:47.662+08	\N
14	14	0	2025-08-26 15:15:02.288+08	2025-08-26 15:15:02.288+08	\N
15	15	0	2025-08-26 15:16:19.188+08	2025-08-26 15:16:19.188+08	\N
16	16	0	2025-08-26 15:22:41.512+08	2025-08-26 15:22:41.512+08	\N
17	17	0	2025-08-26 15:22:41.528+08	2025-08-26 15:22:41.528+08	\N
18	18	0	2025-08-26 15:22:41.549+08	2025-08-26 15:22:41.549+08	\N
19	19	0	2025-08-26 15:22:41.553+08	2025-08-26 15:22:41.553+08	\N
20	20	0	2025-08-26 15:26:17.335+08	2025-08-26 15:26:17.335+08	\N
21	21	0	2025-08-26 15:26:17.346+08	2025-08-26 15:26:17.346+08	\N
22	22	0	2025-08-26 15:49:11.202+08	2025-08-26 15:49:11.202+08	\N
23	23	0	2025-08-26 15:49:11.214+08	2025-08-26 15:49:11.214+08	\N
24	24	0	2025-08-26 18:30:34.729+08	2025-08-26 18:30:34.729+08	\N
25	25	0	2025-08-26 18:33:49.972+08	2025-08-26 18:33:49.972+08	\N
26	26	0	2025-08-26 18:33:49.979+08	2025-08-26 18:33:49.979+08	\N
27	27	0	2025-08-26 18:35:56.59+08	2025-08-26 18:35:56.59+08	\N
28	28	0	2025-08-26 18:35:56.597+08	2025-08-26 18:35:56.597+08	\N
29	29	0	2025-08-26 18:38:45.958+08	2025-08-26 18:38:45.958+08	\N
30	30	0	2025-08-26 18:38:45.965+08	2025-08-26 18:38:45.965+08	\N
31	31	0	2025-08-26 18:38:45.968+08	2025-08-26 18:38:45.968+08	\N
32	32	0	2025-08-26 18:39:08.292+08	2025-08-26 18:39:08.292+08	\N
40	47	0	2025-08-26 19:40:03.189+08	2025-08-26 19:40:03.189+08	\N
41	48	0	2025-08-26 19:40:03.2+08	2025-08-26 19:40:03.2+08	\N
42	49	0	2025-08-26 19:40:03.206+08	2025-08-26 19:40:03.206+08	\N
\.


--
-- Data for Name: InventoryBreakPacks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InventoryBreakPacks" (id, "fromCombinationId", "toCombinationId", "fromQuantity", "toQuantity", reason, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StockAdjustments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StockAdjustments" (id, "referenceNo", "combinationId", "systemQuantity", "newQuantity", difference, reason, notes, "createdBy", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: InventoryMovements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."InventoryMovements" (id, type, previous, new, quantity, reference, reason, "createdAt", "updatedAt", "userId", "combinationId", "referenceId") FROM stdin;
\.


--
-- Data for Name: Suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Suppliers" (id, name, contact, email, phone, address, notes, "isActive", "createdAt", "updatedAt", "deletedAt") FROM stdin;
\.


--
-- Data for Name: PurchaseOrders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PurchaseOrders" (id, "purchaseOrderNumber", "supplierId", status, "deliveryDate", "cancellationReason", "totalAmount", notes, "internalNotes", "modeOfPayment", "checkNumber", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SalesOrders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SalesOrders" (id, "salesOrderNumber", "customerId", status, "orderDate", "isDelivery", "isDeliveryCompleted", "deliveryAddress", "deliveryInstructions", "deliveryDate", "cancellationReason", "totalAmount", notes, "internalNotes", "modeOfPayment", "checkNumber", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: OrderStatusHistories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."OrderStatusHistories" (id, "purchaseOrderId", "salesOrderId", status, "changedBy", "changedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PurchaseOrderItems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PurchaseOrderItems" (id, "purchaseOrderId", "combinationId", quantity, "purchasePrice", "totalAmount", discount, "discountNote", unit, "skuSnapshot", "nameSnapshot", "categorySnapshot", "variantSnapshot", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SalesOrderItems; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SalesOrderItems" (id, "salesOrderId", "combinationId", quantity, "originalPrice", "purchasePrice", "totalAmount", discount, unit, "discountNote", "skuSnapshot", "nameSnapshot", "categorySnapshot", "variantSnapshot", "createdAt", "updatedAt", "inventoryId") FROM stdin;
\.


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SequelizeMeta" (name) FROM stdin;
20250818045347_init.js
20250823133453-base-unit-conversion.js
20250826031715-sub-categories.js
\.


--
-- Name: BreakPacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."BreakPacks_id_seq"', 1, false);


--
-- Name: Categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Categories_id_seq"', 8, true);


--
-- Name: Customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Customers_id_seq"', 1, true);


--
-- Name: Inventories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Inventories_id_seq"', 42, true);


--
-- Name: InventoryBreakPacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."InventoryBreakPacks_id_seq"', 1, false);


--
-- Name: InventoryMovements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."InventoryMovements_id_seq"', 1, false);


--
-- Name: OrderStatusHistories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."OrderStatusHistories_id_seq"', 1, false);


--
-- Name: ProductCombinations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ProductCombinations_id_seq"', 57, true);


--
-- Name: Products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Products_id_seq"', 15, true);


--
-- Name: PurchaseOrderItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."PurchaseOrderItems_id_seq"', 1, false);


--
-- Name: PurchaseOrders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."PurchaseOrders_id_seq"', 1, false);


--
-- Name: SalesOrderItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."SalesOrderItems_id_seq"', 1, false);


--
-- Name: SalesOrders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."SalesOrders_id_seq"', 1, false);


--
-- Name: StockAdjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."StockAdjustments_id_seq"', 1, false);


--
-- Name: Suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Suppliers_id_seq"', 1, false);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Users_id_seq"', 2, true);


--
-- Name: VariantTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."VariantTypes_id_seq"', 29, true);


--
-- Name: VariantValues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."VariantValues_id_seq"', 54, true);


--
-- PostgreSQL database dump complete
--

\unrestrict AuEZYJndmIAJknLdfgksHAtng2jOZhe5lxnBXVF7JFZMl8dZSF5ZJoFja91Qvt0

